import time
import math
import sys

# Попытка импорта colorama для цветного вывода (опционально)
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR = True
except ImportError:
    COLOR = False
    # Заглушки, чтобы код не ломался
    class Fore:
        RED = ''
        GREEN = ''
        YELLOW = ''
        CYAN = ''
        MAGENTA = ''
        RESET = ''
    class Style:
        BRIGHT = ''
        RESET_ALL = ''

# Настройки вывода
INDENT = 6          # отступ для дробей при вводе
RESULT_INDENT = 4   # отступ для результата

t = time.sleep
p = print

def cls(n=5):
    """Очистка экрана пустыми строками."""
    print("\n" * n)

def print_header(title):
    """Выводит заголовок в рамке."""
    width = 60
    line = "=" * width
    print(Fore.CYAN + Style.BRIGHT + line)
    print(title.center(width))
    print(line + Style.RESET_ALL)

def print_menu(items):
    """Выводит меню в рамке с нумерацией."""
    width = 60
    print(Fore.YELLOW + "+" + "-" * (width-2) + "+")
    for key, desc in items.items():
        line = f"{key}. {desc}"
        print(f"| {line:<{width-4}} |")
    print("+" + "-" * (width-2) + "+" + Style.RESET_ALL)

def print_result(label, value=None, fraction=None):
    """Красивый вывод результата.
       Если value не None, выводит число, если fraction - кортеж (num, den)."""
    print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
    if value is not None:
        print(" " * RESULT_INDENT + str(value))
    elif fraction is not None:
        num, den = fraction
        # используем существующую функцию печати дроби (адаптированную)
        print_fraction_simple(num, den, RESULT_INDENT)
    else:
        print(" " * RESULT_INDENT + "?")
    print()

def print_fraction_simple(num, den, indent=0):
    """Упрощённый вывод дроби (числитель, черта, знаменатель) с выравниванием."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    prefix = " " * indent
    print(prefix + num_str.rjust(width))
    print(prefix + line)
    print(prefix + den_str.rjust(width))

def show_fraction(x_val=None, y_val=None, indent=INDENT):
    """Отображает дробь x / y с отступом слева."""
    x_disp = str(x_val) if x_val is not None else 'x'
    y_disp = str(y_val) if y_val is not None else 'y'
    width = max(len(x_disp), len(y_disp))
    line = "—" * width
    prefix = " " * indent
    print(prefix + x_disp.rjust(width))
    print(prefix + line)
    print(prefix + y_disp.rjust(width))

def draw_fraction(num, den):
    """Подготавливает строки для отображения дроби num/den с чертой."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    return num_str, line, den_str, width

def mixed_fraction(x, y):
    """Преобразует дробь x/y в смешанную.
    Возвращает (знак, целая_часть, числитель_остатка, знаменатель).
    """
    if y == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    sign = '-' if x * y < 0 else ''
    ax, ay = abs(x), abs(y)
    whole = ax // ay
    rem = ax % ay
    if rem == 0:
        return sign, whole, None, None
    if whole == 0:
        return sign, None, rem, ay
    return sign, whole, rem, ay

def print_result_mixed(x, y):
    """Печатает результат x/y в виде смешанной дроби с форматированием."""
    try:
        sign, whole, num, den = mixed_fraction(x, y)
    except ValueError as e:
        p("Ошибка:", e)
        return

    if num is None:                     # целое число
        p(" " * RESULT_INDENT + f"{sign}{whole}")
    elif whole is None:                  # правильная дробь
        n, line, d, L = draw_fraction(num, den)
        if sign:
            offset = 2
            p(" " * RESULT_INDENT + " " * (offset + (L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + "- " + line)
            p(" " * RESULT_INDENT + " " * (offset + (L - len(d)) // 2) + d)
        else:
            p(" " * RESULT_INDENT + " " * ((L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + line)
            p(" " * RESULT_INDENT + " " * ((L - len(d)) // 2) + d)
    else:                                # смешанная дробь
        n, line, d, L = draw_fraction(num, den)
        offset_drob = len(f"{sign}{whole} ") if sign else len(f"{whole} ")
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(n)) // 2) + n)
        p(" " * RESULT_INDENT + f"{sign}{whole} " + line)
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(d)) // 2) + d)

def reduce_fraction(x, y):
    """Сокращает дробь x/y, возвращает (числитель, знаменатель)."""
    g = math.gcd(x, y)
    return x // g, y // g

def add_fractions(x1, y1, x2, y2):
    """Сложение дробей x1/y1 + x2/y2."""
    num = x1 * y2 + x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def sub_fractions(x1, y1, x2, y2):
    """Вычитание дробей x1/y1 - x2/y2."""
    num = x1 * y2 - x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def mul_fractions(x1, y1, x2, y2):
    """Умножение дробей (x1/y1) * (x2/y2)."""
    num = x1 * x2
    den = y1 * y2
    return reduce_fraction(num, den)

def div_fractions(x1, y1, x2, y2):
    """Деление дробей (x1/y1) / (x2/y2)."""
    if x2 == 0:
        raise ValueError("Деление на ноль!")
    num = x1 * y2
    den = y1 * x2
    return reduce_fraction(num, den)

def gcd_numbers(a, b):
    """НОД двух целых чисел."""
    return math.gcd(a, b)

def lcm_numbers(a, b):
    """НОК двух целых чисел."""
    return abs(a * b) // math.gcd(a, b) if a != 0 and b != 0 else 0

def simple_calculator():
    """Обычный калькулятор для целых чисел с операциями +, -, *, /."""
    cls(1)
    print_header("         ОБЫЧНЫЙ КАЛЬКУЛЯТОР         ")
    try:
        a = int(input("Введите первое число: "))
        op = input("Введите операцию (+, -, *, /): ").strip()
        b = int(input("Введите второе число: "))
    except ValueError:
        p(Fore.RED + "Ошибка: необходимо вводить целые числа." + Style.RESET_ALL)
        return

    if op not in ('+', '-', '*', '/'):
        p(Fore.RED + "Ошибка: неверная операция." + Style.RESET_ALL)
        return

    if op == '/' and b == 0:
        p(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
        return

    # Вычисление
    if op == '+':
        res = a + b
        print_result("Результат:", value=res)
    elif op == '-':
        res = a - b
        print_result("Результат:", value=res)
    elif op == '*':
        res = a * b
        print_result("Результат:", value=res)
    elif op == '/':
        # Деление: выводим в виде десятичной дроби с двумя знаками, а также как обыкновенную дробь
        if a % b == 0:
            res = a // b
            print_result("Результат (целый):", value=res)
        else:
            # Сокращаем дробь
            num, den = reduce_fraction(a, b)
            dec = a / b
            # Красивый вывод
            print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
            print(" " * RESULT_INDENT + f"Десятичная: {dec:.10f}".rstrip('0').rstrip('.'))
            print(" " * RESULT_INDENT + "Обыкновенная:")
            print_fraction_simple(num, den, RESULT_INDENT + 2)
    else:
        # Не должно быть
        pass

def input_fraction(prompt):
    """Запрашивает у пользователя числитель и знаменатель, возвращает (x, y)."""
    cls(1)
    p(Fore.MAGENTA + prompt + Style.RESET_ALL)
    show_fraction()
    x = int(input("x = "))
    cls(1)
    p(Fore.MAGENTA + "Введите знаменатель:" + Style.RESET_ALL)
    show_fraction(x_val=x)
    y = int(input("y = "))
    return x, y

def input_two_numbers(prompt1, prompt2):
    """Запрашивает два целых числа, возвращает (a, b)."""
    cls(1)
    p(Fore.MAGENTA + prompt1 + Style.RESET_ALL)
    a = int(input("a = "))
    cls(1)
    p(Fore.MAGENTA + prompt2 + Style.RESET_ALL)
    b = int(input("b = "))
    return a, b

def main():
    while True:
        cls(3)
        print_header("         КАЛЬКУЛЯТОР ДРОБЕЙ И ЧИСЕЛ         ")
        menu_items = {
            '1': 'Сократить дробь',
            '2': 'Сложить две дроби',
            '3': 'Вычесть две дроби',
            '4': 'Умножить две дроби',
            '5': 'Разделить две дроби',
            '6': 'Преобразовать в смешанную',
            '7': 'НОД двух чисел',
            '8': 'НОК двух чисел',
            '9': 'Обычный калькулятор (+, -, *, /)',
            '0': 'Выход'
        }
        print_menu(menu_items)
        choice = input("Выберите действие: ").strip()

        if choice == '0':
            print_header("         ДО СВИДАНИЯ!         ")
            break

        elif choice == '1':   # сократить
            x, y = input_fraction("Введите дробь для сокращения:")
            try:
                nx, ny = reduce_fraction(x, y)
                print_result("Сокращённая дробь:", fraction=(nx, ny))
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '2':   # сложение
            p("Первая дробь:")
            x1, y1 = input_fraction("Введите первую дробь:")
            p("Вторая дробь:")
            x2, y2 = input_fraction("Введите вторую дробь:")
            try:
                nx, ny = add_fractions(x1, y1, x2, y2)
                print_result("Сумма дробей:", fraction=(nx, ny))
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '3':   # вычитание
            p("Первая дробь:")
            x1, y1 = input_fraction("Введите первую дробь:")
            p("Вторая дробь:")
            x2, y2 = input_fraction("Введите вторую дробь:")
            try:
                nx, ny = sub_fractions(x1, y1, x2, y2)
                print_result("Разность дробей:", fraction=(nx, ny))
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '4':   # умножение
            p("Первая дробь:")
            x1, y1 = input_fraction("Введите первую дробь:")
            p("Вторая дробь:")
            x2, y2 = input_fraction("Введите вторую дробь:")
            try:
                nx, ny = mul_fractions(x1, y1, x2, y2)
                print_result("Произведение дробей:", fraction=(nx, ny))
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '5':   # деление
            p("Первая дробь (делимое):")
            x1, y1 = input_fraction("Введите первую дробь:")
            p("Вторая дробь (делитель):")
            x2, y2 = input_fraction("Введите вторую дробь:")
            try:
                nx, ny = div_fractions(x1, y1, x2, y2)
                print_result("Частное дробей:", fraction=(nx, ny))
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '6':   # преобразовать в смешанную
            x, y = input_fraction("Введите дробь для преобразования:")
            try:
                p("Смешанная дробь:")
                print_result_mixed(x, y)
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '7':   # НОД
            a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
            try:
                res = gcd_numbers(a, b)
                print_result(f"НОД({a}, {b}) =", value=res)
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '8':   # НОК
            a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
            try:
                res = lcm_numbers(a, b)
                print_result(f"НОК({a}, {b}) =", value=res)
            except Exception as e:
                p(Fore.RED + "Ошибка:" + Style.RESET_ALL, e)

        elif choice == '9':   # Обычный калькулятор
            simple_calculator()

        else:
            p(Fore.RED + "Неверный выбор. Попробуйте снова." + Style.RESET_ALL)

        t(1.5)
        input("\nНажмите Enter, чтобы продолжить...")

if __name__ == "__main__":
    main()