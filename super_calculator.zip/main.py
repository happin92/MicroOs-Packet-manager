import time
import math
import sys

# Попытка импорта colorama для цветного вывода (опционально)
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR = True
except ImportError:
    COLOR = False
    # Заглушки, чтобы код не ломался
    class Fore:
        RED = ''
        GREEN = ''
        YELLOW = ''
        CYAN = ''
        MAGENTA = ''
        RESET = ''
    class Style:
        BRIGHT = ''
        RESET_ALL = ''

# Настройки вывода
INDENT = 6          # отступ для дробей при вводе
RESULT_INDENT = 4   # отступ для результата

t = time.sleep
p = print

def cls(n=5):
    """Очистка экрана пустыми строками."""
    print("\n" * n)

def print_header(title):
    """Выводит заголовок в рамке."""
    width = 60
    line = "=" * width
    print(Fore.CYAN + Style.BRIGHT + line)
    print(title.center(width))
    print(line + Style.RESET_ALL)

def print_menu(items):
    """Выводит меню в рамке с нумерацией."""
    width = 60
    print(Fore.YELLOW + "+" + "-" * (width-2) + "+")
    for key, desc in items.items():
        line = f"{key}. {desc}"
        print(f"| {line:<{width-4}} |")
    print("+" + "-" * (width-2) + "+" + Style.RESET_ALL)

def print_result(label, value=None, fraction=None):
    """Красивый вывод результата.
       Если value не None, выводит число, если fraction - кортеж (num, den)."""
    print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
    if value is not None:
        print(" " * RESULT_INDENT + str(value))
    elif fraction is not None:
        num, den = fraction
        print_fraction_simple(num, den, RESULT_INDENT)
    else:
        print(" " * RESULT_INDENT + "?")
    print()

def print_fraction_simple(num, den, indent=0):
    """Упрощённый вывод дроби (числитель, черта, знаменатель) с выравниванием."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    prefix = " " * indent
    print(prefix + num_str.rjust(width))
    print(prefix + line)
    print(prefix + den_str.rjust(width))

def show_fraction(x_val=None, y_val=None, indent=INDENT):
    """Отображает дробь x / y с отступом слева."""
    x_disp = str(x_val) if x_val is not None else 'x'
    y_disp = str(y_val) if y_val is not None else 'y'
    width = max(len(x_disp), len(y_disp))
    line = "—" * width
    prefix = " " * indent
    print(prefix + x_disp.rjust(width))
    print(prefix + line)
    print(prefix + y_disp.rjust(width))

def draw_fraction(num, den):
    """Подготавливает строки для отображения дроби num/den с чертой."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    return num_str, line, den_str, width

def mixed_fraction(x, y):
    """Преобразует дробь x/y в смешанную.
    Возвращает (знак, целая_часть, числитель_остатка, знаменатель).
    """
    if y == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    sign = '-' if x * y < 0 else ''
    ax, ay = abs(x), abs(y)
    whole = ax // ay
    rem = ax % ay
    if rem == 0:
        return sign, whole, None, None
    if whole == 0:
        return sign, None, rem, ay
    return sign, whole, rem, ay

def print_result_mixed(x, y):
    """Печатает результат x/y в виде смешанной дроби с форматированием."""
    try:
        sign, whole, num, den = mixed_fraction(x, y)
    except ValueError as e:
        p(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        return

    if num is None:                     # целое число
        p(" " * RESULT_INDENT + f"{sign}{whole}")
    elif whole is None:                  # правильная дробь
        n, line, d, L = draw_fraction(num, den)
        if sign:
            offset = 2
            p(" " * RESULT_INDENT + " " * (offset + (L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + "- " + line)
            p(" " * RESULT_INDENT + " " * (offset + (L - len(d)) // 2) + d)
        else:
            p(" " * RESULT_INDENT + " " * ((L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + line)
            p(" " * RESULT_INDENT + " " * ((L - len(d)) // 2) + d)
    else:                                # смешанная дробь
        n, line, d, L = draw_fraction(num, den)
        offset_drob = len(f"{sign}{whole} ") if sign else len(f"{whole} ")
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(n)) // 2) + n)
        p(" " * RESULT_INDENT + f"{sign}{whole} " + line)
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(d)) // 2) + d)

def reduce_fraction(x, y):
    """Сокращает дробь x/y, возвращает (числитель, знаменатель)."""
    if y == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    g = math.gcd(x, y)
    return x // g, y // g

def add_fractions(x1, y1, x2, y2):
    """Сложение дробей x1/y1 + x2/y2."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * y2 + x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def sub_fractions(x1, y1, x2, y2):
    """Вычитание дробей x1/y1 - x2/y2."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * y2 - x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def mul_fractions(x1, y1, x2, y2):
    """Умножение дробей (x1/y1) * (x2/y2)."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * x2
    den = y1 * y2
    return reduce_fraction(num, den)

def div_fractions(x1, y1, x2, y2):
    """Деление дробей (x1/y1) / (x2/y2)."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    if x2 == 0:
        raise ValueError("Деление на ноль!")
    num = x1 * y2
    den = y1 * x2
    return reduce_fraction(num, den)

def gcd_numbers(a, b):
    """НОД двух целых чисел."""
    return math.gcd(a, b)

def lcm_numbers(a, b):
    """НОК двух целых чисел."""
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // math.gcd(a, b)

def safe_int_input(prompt):
    """Запрашивает целое число, повторяя при ошибке."""
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print(Fore.RED + "Ошибка: введите целое число." + Style.RESET_ALL)

def safe_float_input(prompt):
    """Запрашивает число с плавающей точкой, повторяя при ошибке."""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print(Fore.RED + "Ошибка: введите число." + Style.RESET_ALL)

def simple_calculator():
    """Обычный калькулятор для целых чисел с операциями +, -, *, /."""
    cls(1)
    print_header("         ОБЫЧНЫЙ КАЛЬКУЛЯТОР         ")
    a = safe_int_input("Введите первое число: ")
    op = input("Введите операцию (+, -, *, /): ").strip()
    while op not in ('+', '-', '*', '/'):
        print(Fore.RED + "Ошибка: неверная операция. Попробуйте снова." + Style.RESET_ALL)
        op = input("Введите операцию (+, -, *, /): ").strip()
    b = safe_int_input("Введите второе число: ")

    if op == '/' and b == 0:
        print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
        return

    if op == '+':
        res = a + b
        print_result("Результат:", value=res)
    elif op == '-':
        res = a - b
        print_result("Результат:", value=res)
    elif op == '*':
        res = a * b
        print_result("Результат:", value=res)
    elif op == '/':
        if a % b == 0:
            res = a // b
            print_result("Результат (целый):", value=res)
        else:
            num, den = reduce_fraction(a, b)
            dec = a / b
            print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
            print(" " * RESULT_INDENT + f"Десятичная: {dec:.10f}".rstrip('0').rstrip('.'))
            print(" " * RESULT_INDENT + "Обыкновенная:")
            print_fraction_simple(num, den, RESULT_INDENT + 2)

def engineering_calculator():
    """Инженерный калькулятор с тригонометрическими, логарифмическими и другими функциями."""
    deg_mode = False  # False - радианы, True - градусы

    def to_radians(x):
        return math.radians(x) if deg_mode else x

    def from_radians(x):
        return math.degrees(x) if deg_mode else x

    while True:
        cls(1)
        print_header("         ИНЖЕНЕРНЫЙ КАЛЬКУЛЯТОР         ")
        mode_str = "ГРАДУСЫ" if deg_mode else "РАДИАНЫ"
        print(Fore.YELLOW + f"Текущий режим углов: {mode_str}" + Style.RESET_ALL)
        print()
        print("Доступные операции:")
        menu = {
            '1': 'sin(x)',
            '2': 'cos(x)',
            '3': 'tan(x)',
            '4': 'asin(x)',
            '5': 'acos(x)',
            '6': 'atan(x)',
            '7': 'sqrt(x)',
            '8': 'log10(x) (десятичный логарифм)',
            '9': 'ln(x) (натуральный логарифм)',
            '10': 'exp(x) (e^x)',
            '11': 'x^y (возведение в степень)',
            '12': 'log(x, base)',
            '13': '|x| (модуль)',
            '14': 'x! (факториал, целое x >= 0)',
            '15': 'Константы (pi, e)',
            '16': 'Переключить режим углов (радианы/градусы)',
            '0': 'Назад в главное меню'
        }
        for key, desc in menu.items():
            print(f"  {key}. {desc}")
        print()

        choice = input("Выберите операцию: ").strip()
        if choice == '0':
            break
        elif choice == '16':
            deg_mode = not deg_mode
            continue
        elif choice == '15':
            cls(1)
            print("Константы:")
            print("  p - число π (пи)")
            print("  e - число e")
            const = input("Выберите константу: ").strip().lower()
            if const == 'p':
                print_result("π =", value=math.pi)
            elif const == 'e':
                print_result("e =", value=math.e)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        try:
            if choice in ('11', '12'):
                x = safe_float_input("Введите x: ")
                y = safe_float_input("Введите y: ")
            else:
                x = safe_float_input("Введите x: ")
        except Exception as e:
            print(Fore.RED + "Ошибка ввода: " + str(e) + Style.RESET_ALL)
            t(1.5)
            continue

        result = None
        error = None

        try:
            if choice == '1':
                result = math.sin(to_radians(x))
            elif choice == '2':
                result = math.cos(to_radians(x))
            elif choice == '3':
                result = math.tan(to_radians(x))
            elif choice == '4':
                if x < -1 or x > 1:
                    error = "Аргумент должен быть в [-1, 1]"
                else:
                    result = from_radians(math.asin(x))
            elif choice == '5':
                if x < -1 or x > 1:
                    error = "Аргумент должен быть в [-1, 1]"
                else:
                    result = from_radians(math.acos(x))
            elif choice == '6':
                result = from_radians(math.atan(x))
            elif choice == '7':
                if x < 0:
                    error = "Аргумент должен быть неотрицательным"
                else:
                    result = math.sqrt(x)
            elif choice == '8':
                if x <= 0:
                    error = "Аргумент должен быть положительным"
                else:
                    result = math.log10(x)
            elif choice == '9':
                if x <= 0:
                    error = "Аргумент должен быть положительным"
                else:
                    result = math.log(x)
            elif choice == '10':
                result = math.exp(x)
            elif choice == '11':
                result = math.pow(x, y)
            elif choice == '12':
                if x <= 0 or y <= 0 or y == 1:
                    error = "Аргументы должны быть положительными, основание не равно 1"
                else:
                    result = math.log(x, y)
            elif choice == '13':
                result = abs(x)
            elif choice == '14':
                if x < 0 or x != int(x):
                    error = "Факториал определён только для целых неотрицательных чисел"
                else:
                    result = math.factorial(int(x))
            else:
                error = "Неизвестная операция"
        except Exception as e:
            error = str(e)

        if error:
            print(Fore.RED + "Ошибка: " + error + Style.RESET_ALL)
        else:
            if result is not None:
                if isinstance(result, float) and result.is_integer():
                    result = int(result)
                print_result("Результат:", value=result)
        t(1.5)

def solve_equations():
    """Решение уравнений: линейных (с выбором операции) и квадратных."""
    while True:
        cls(1)
        print_header("         РЕШЕНИЕ УРАВНЕНИЙ         ")
        print("Выберите тип уравнения:")
        menu = {
            '1': 'Линейное уравнение: a · x ? b = c',
            '2': 'Квадратное уравнение: a·x² + b·x + c = d',
            '0': 'Назад в главное меню'
        }
        for key, desc in menu.items():
            print(f"  {key}. {desc}")
        print()

        choice = input("Выберите действие: ").strip()

        if choice == '0':
            break
        elif choice == '1':
            cls(1)
            print_header("         ЛИНЕЙНОЕ УРАВНЕНИЕ a · x ? b = c         ")
            a = safe_float_input("Введите коэффициент a: ")
            op = input("Выберите операцию (+, -, *, /) между a·x и b: ").strip()
            while op not in ('+', '-', '*', '/'):
                print(Fore.RED + "Ошибка: неверная операция." + Style.RESET_ALL)
                op = input("Выберите операцию (+, -, *, /): ").strip()
            b = safe_float_input("Введите коэффициент b: ")
            c = safe_float_input("Введите правую часть c: ")

            if a == 0:
                if op == '+':
                    lhs = b
                elif op == '-':
                    lhs = -b
                elif op == '*':
                    lhs = 0
                elif op == '/':
                    if b == 0:
                        print(Fore.RED + "Ошибка: деление нуля на ноль." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    lhs = 0
                if lhs == c:
                    print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                else:
                    print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                t(1.5)
                continue

            try:
                if op == '+':
                    x = (c - b) / a
                elif op == '-':
                    x = (c + b) / a
                elif op == '*':
                    if b == 0:
                        if c == 0:
                            print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                        else:
                            print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    x = c / (a * b)
                elif op == '/':
                    if b == 0:
                        print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    x = c * b / a
            except ZeroDivisionError:
                print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
                t(1.5)
                continue

            if x.is_integer():
                x = int(x)
            print_result("Корень уравнения:", value=x)
            t(1.5)

        elif choice == '2':
            cls(1)
            print_header("         КВАДРАТНОЕ УРАВНЕНИЕ a·x² + b·x + c = d         ")
            a = safe_float_input("Введите коэффициент a: ")
            b = safe_float_input("Введите коэффициент b: ")
            c = safe_float_input("Введите коэффициент c: ")
            d = safe_float_input("Введите правую часть d: ")

            c_adj = c - d

            if a == 0:
                print(Fore.YELLOW + "Коэффициент a = 0, уравнение становится линейным." + Style.RESET_ALL)
                if b == 0:
                    if c_adj == 0:
                        print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                    else:
                        print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                else:
                    x = -c_adj / b
                    if x.is_integer():
                        x = int(x)
                    print_result("Корень уравнения:", value=x)
            else:
                D = b**2 - 4*a*c_adj
                print(Fore.CYAN + f"Дискриминант D = {D}" + Style.RESET_ALL)

                if D < 0:
                    print(Fore.RED + "Действительных корней нет." + Style.RESET_ALL)
                elif D == 0:
                    x = -b / (2*a)
                    if x.is_integer():
                        x = int(x)
                    print_result("Один корень (два совпадающих):", value=x)
                else:
                    sqrt_D = math.sqrt(D)
                    x1 = (-b + sqrt_D) / (2*a)
                    x2 = (-b - sqrt_D) / (2*a)
                    if x1.is_integer():
                        x1 = int(x1)
                    if x2.is_integer():
                        x2 = int(x2)
                    print(" " * RESULT_INDENT + "Корни уравнения:")
                    print(" " * (RESULT_INDENT+2) + f"x₁ = {x1}")
                    print(" " * (RESULT_INDENT+2) + f"x₂ = {x2}")
            t(1.5)
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)

def input_fraction(prompt):
    """Запрашивает у пользователя числитель и знаменатель, возвращает (x, y)."""
    cls(1)
    print(Fore.MAGENTA + prompt + Style.RESET_ALL)
    show_fraction()
    x = safe_int_input("x = ")
    cls(1)
    print(Fore.MAGENTA + "Введите знаменатель:" + Style.RESET_ALL)
    show_fraction(x_val=x)
    y = safe_int_input("y = ")
    return x, y

def input_two_numbers(prompt1, prompt2):
    """Запрашивает два целых числа, возвращает (a, b)."""
    cls(1)
    print(Fore.MAGENTA + prompt1 + Style.RESET_ALL)
    a = safe_int_input("a = ")
    cls(1)
    print(Fore.MAGENTA + prompt2 + Style.RESET_ALL)
    b = safe_int_input("b = ")
    return a, b

def main():
    while True:
        try:
            cls(3)
            print_header("         КАЛЬКУЛЯТОР ДРОБЕЙ И ЧИСЕЛ         ")
            menu_items = {
                '1': 'Сократить дробь',
                '2': 'Сложить две дроби',
                '3': 'Вычесть две дроби',
                '4': 'Умножить две дроби',
                '5': 'Разделить две дроби',
                '6': 'Преобразовать в смешанную',
                '7': 'НОД двух чисел',
                '8': 'НОК двух чисел',
                '9': 'Обычный калькулятор (+, -, *, /)',
                '10': 'Инженерный калькулятор',
                '11': 'Решение уравнений',
                '0': 'Выход'
            }
            print_menu(menu_items)
            choice = input("Выберите действие: ").strip()

            if choice == '0':
                print_header("         ДО СВИДАНИЯ!         ")
                break

            elif choice == '1':
                x, y = input_fraction("Введите дробь для сокращения:")
                nx, ny = reduce_fraction(x, y)
                print_result("Сокращённая дробь:", fraction=(nx, ny))

            elif choice == '2':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = add_fractions(x1, y1, x2, y2)
                print_result("Сумма дробей:", fraction=(nx, ny))

            elif choice == '3':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = sub_fractions(x1, y1, x2, y2)
                print_result("Разность дробей:", fraction=(nx, ny))

            elif choice == '4':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = mul_fractions(x1, y1, x2, y2)
                print_result("Произведение дробей:", fraction=(nx, ny))

            elif choice == '5':
                print("Первая дробь (делимое):")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь (делитель):")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = div_fractions(x1, y1, x2, y2)
                print_result("Частное дробей:", fraction=(nx, ny))

            elif choice == '6':
                x, y = input_fraction("Введите дробь для преобразования:")
                print("Смешанная дробь:")
                print_result_mixed(x, y)

            elif choice == '7':
                a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
                res = gcd_numbers(a, b)
                print_result(f"НОД({a}, {b}) =", value=res)

            elif choice == '8':
                a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
                res = lcm_numbers(a, b)
                print_result(f"НОК({a}, {b}) =", value=res)

            elif choice == '9':
                simple_calculator()

            elif choice == '10':
                engineering_calculator()

            elif choice == '11':
                solve_equations()

            else:
                print(Fore.RED + "Неверный выбор. Попробуйте снова." + Style.RESET_ALL)

        except KeyboardInterrupt:
            print(Fore.YELLOW + "\nВыход по запросу пользователя." + Style.RESET_ALL)
            break
        except Exception as e:
            print(Fore.RED + "Произошла непредвиденная ошибка: " + str(e) + Style.RESET_ALL)
            t(1.5)

        t(1.5)
        input("\nНажмите Enter, чтобы продолжить...")

if __name__ == "__main__":
    main()