import time
import math
import sys
import statistics
import random
import datetime
import cmath
from fractions import Fraction

# Попытка импорта colorama для цветного вывода (опционально)
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR = True
except ImportError:
    COLOR = False
    # Заглушки, чтобы код не ломался
    class Fore:
        RED = ''
        GREEN = ''
        YELLOW = ''
        CYAN = ''
        MAGENTA = ''
        RESET = ''
    class Style:
        BRIGHT = ''
        RESET_ALL = ''

# Настройки вывода
INDENT = 6          # отступ для дробей при вводе
RESULT_INDENT = 4   # отступ для результата

t = time.sleep
p = print

def cls(n=5):
    """Очистка экрана пустыми строками."""
    print("\n" * n)

def print_header(title):
    """Выводит заголовок в рамке."""
    width = 60
    line = "=" * width
    print(Fore.CYAN + Style.BRIGHT + line)
    print(title.center(width))
    print(line + Style.RESET_ALL)

def print_menu(items):
    """Выводит меню в рамке с нумерацией."""
    width = 60
    print(Fore.YELLOW + "+" + "-" * (width-2) + "+")
    for key, desc in items.items():
        line = f"{key}. {desc}"
        print(f"| {line:<{width-4}} |")
    print("+" + "-" * (width-2) + "+" + Style.RESET_ALL)

def print_result(label, value=None, fraction=None):
    """Красивый вывод результата.
       Если value не None, выводит число, если fraction - кортеж (num, den)."""
    print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
    if value is not None:
        print(" " * RESULT_INDENT + str(value))
    elif fraction is not None:
        num, den = fraction
        print_fraction_simple(num, den, RESULT_INDENT)
    else:
        print(" " * RESULT_INDENT + "?")
    print()

def print_fraction_simple(num, den, indent=0):
    """Упрощённый вывод дроби (числитель, черта, знаменатель) с выравниванием."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    prefix = " " * indent
    print(prefix + num_str.rjust(width))
    print(prefix + line)
    print(prefix + den_str.rjust(width))

def show_fraction(x_val=None, y_val=None, indent=INDENT):
    """Отображает дробь x / y с отступом слева."""
    x_disp = str(x_val) if x_val is not None else 'x'
    y_disp = str(y_val) if y_val is not None else 'y'
    width = max(len(x_disp), len(y_disp))
    line = "—" * width
    prefix = " " * indent
    print(prefix + x_disp.rjust(width))
    print(prefix + line)
    print(prefix + y_disp.rjust(width))

def draw_fraction(num, den):
    """Подготавливает строки для отображения дроби num/den с чертой."""
    num_str = str(num)
    den_str = str(den)
    width = max(len(num_str), len(den_str))
    line = "—" * width
    return num_str, line, den_str, width

def mixed_fraction(x, y):
    """Преобразует дробь x/y в смешанную.
    Возвращает (знак, целая_часть, числитель_остатка, знаменатель).
    """
    if y == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    sign = '-' if x * y < 0 else ''
    ax, ay = abs(x), abs(y)
    whole = ax // ay
    rem = ax % ay
    if rem == 0:
        return sign, whole, None, None
    if whole == 0:
        return sign, None, rem, ay
    return sign, whole, rem, ay

def print_result_mixed(x, y):
    """Печатает результат x/y в виде смешанной дроби с форматированием."""
    try:
        sign, whole, num, den = mixed_fraction(x, y)
    except ValueError as e:
        p(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        return

    if num is None:                     # целое число
        p(" " * RESULT_INDENT + f"{sign}{whole}")
    elif whole is None:                  # правильная дробь
        n, line, d, L = draw_fraction(num, den)
        if sign:
            offset = 2
            p(" " * RESULT_INDENT + " " * (offset + (L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + "- " + line)
            p(" " * RESULT_INDENT + " " * (offset + (L - len(d)) // 2) + d)
        else:
            p(" " * RESULT_INDENT + " " * ((L - len(n)) // 2) + n)
            p(" " * RESULT_INDENT + line)
            p(" " * RESULT_INDENT + " " * ((L - len(d)) // 2) + d)
    else:                                # смешанная дробь
        n, line, d, L = draw_fraction(num, den)
        offset_drob = len(f"{sign}{whole} ") if sign else len(f"{whole} ")
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(n)) // 2) + n)
        p(" " * RESULT_INDENT + f"{sign}{whole} " + line)
        p(" " * RESULT_INDENT + " " * offset_drob + " " * ((L - len(d)) // 2) + d)

def reduce_fraction(x, y):
    """Сокращает дробь x/y, возвращает (числитель, знаменатель)."""
    if y == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    g = math.gcd(x, y)
    return x // g, y // g

def add_fractions(x1, y1, x2, y2):
    """Сложение дробей x1/y1 + x2/y2."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * y2 + x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def sub_fractions(x1, y1, x2, y2):
    """Вычитание дробей x1/y1 - x2/y2."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * y2 - x2 * y1
    den = y1 * y2
    return reduce_fraction(num, den)

def mul_fractions(x1, y1, x2, y2):
    """Умножение дробей (x1/y1) * (x2/y2)."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    num = x1 * x2
    den = y1 * y2
    return reduce_fraction(num, den)

def div_fractions(x1, y1, x2, y2):
    """Деление дробей (x1/y1) / (x2/y2)."""
    if y1 == 0 or y2 == 0:
        raise ValueError("Знаменатель не может быть нулём!")
    if x2 == 0:
        raise ValueError("Деление на ноль!")
    num = x1 * y2
    den = y1 * x2
    return reduce_fraction(num, den)

def gcd_numbers(a, b):
    """НОД двух целых чисел."""
    return math.gcd(a, b)

def lcm_numbers(a, b):
    """НОК двух целых чисел."""
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // math.gcd(a, b)

def safe_int_input(prompt):
    """Запрашивает целое число, повторяя при ошибке."""
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print(Fore.RED + "Ошибка: введите целое число." + Style.RESET_ALL)

def safe_float_input(prompt):
    """Запрашивает число с плавающей точкой, повторяя при ошибке."""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print(Fore.RED + "Ошибка: введите число." + Style.RESET_ALL)

def safe_complex_input(prompt):
    """Запрашивает комплексное число (формат: a+bj или a+b*i)."""
    while True:
        try:
            s = input(prompt).strip().replace(' ', '').replace('i', 'j')
            return complex(s)
        except ValueError:
            print(Fore.RED + "Ошибка: введите комплексное число (например, 3+4j)." + Style.RESET_ALL)

def safe_choice(prompt, valid_options):
    """Запрашивает выбор из списка допустимых значений."""
    while True:
        ch = input(prompt).strip().lower()
        if ch in valid_options:
            return ch
        print(Fore.RED + "Неверный выбор. Попробуйте снова." + Style.RESET_ALL)

# ========== ОСНОВНЫЕ ФУНКЦИИ (УЖЕ БЫЛИ) ==========

def simple_calculator():
    """Обычный калькулятор для целых чисел с операциями +, -, *, /."""
    cls(1)
    print_header("         ОБЫЧНЫЙ КАЛЬКУЛЯТОР         ")
    a = safe_int_input("Введите первое число: ")
    op = input("Введите операцию (+, -, *, /): ").strip()
    while op not in ('+', '-', '*', '/'):
        print(Fore.RED + "Ошибка: неверная операция. Попробуйте снова." + Style.RESET_ALL)
        op = input("Введите операцию (+, -, *, /): ").strip()
    b = safe_int_input("Введите второе число: ")

    if op == '/' and b == 0:
        print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
        return

    if op == '+':
        res = a + b
        print_result("Результат:", value=res)
    elif op == '-':
        res = a - b
        print_result("Результат:", value=res)
    elif op == '*':
        res = a * b
        print_result("Результат:", value=res)
    elif op == '/':
        if a % b == 0:
            res = a // b
            print_result("Результат (целый):", value=res)
        else:
            num, den = reduce_fraction(a, b)
            dec = a / b
            print(Fore.GREEN + Style.BRIGHT + "▶ РЕЗУЛЬТАТ:" + Style.RESET_ALL)
            print(" " * RESULT_INDENT + f"Десятичная: {dec:.10f}".rstrip('0').rstrip('.'))
            print(" " * RESULT_INDENT + "Обыкновенная:")
            print_fraction_simple(num, den, RESULT_INDENT + 2)

def engineering_calculator():
    """Инженерный калькулятор с тригонометрическими, логарифмическими и другими функциями."""
    deg_mode = False  # False - радианы, True - градусы

    def to_radians(x):
        return math.radians(x) if deg_mode else x

    def from_radians(x):
        return math.degrees(x) if deg_mode else x

    while True:
        cls(1)
        print_header("         ИНЖЕНЕРНЫЙ КАЛЬКУЛЯТОР         ")
        mode_str = "ГРАДУСЫ" if deg_mode else "РАДИАНЫ"
        print(Fore.YELLOW + f"Текущий режим углов: {mode_str}" + Style.RESET_ALL)
        print()
        print("Доступные операции:")
        menu = {
            '1': 'sin(x)',
            '2': 'cos(x)',
            '3': 'tan(x)',
            '4': 'asin(x)',
            '5': 'acos(x)',
            '6': 'atan(x)',
            '7': 'sqrt(x)',
            '8': 'log10(x) (десятичный логарифм)',
            '9': 'ln(x) (натуральный логарифм)',
            '10': 'exp(x) (e^x)',
            '11': 'x^y (возведение в степень)',
            '12': 'log(x, base)',
            '13': '|x| (модуль)',
            '14': 'x! (факториал, целое x >= 0)',
            '15': 'Константы (pi, e)',
            '16': 'Переключить режим углов (радианы/градусы)',
            '0': 'Назад в главное меню'
        }
        for key, desc in menu.items():
            print(f"  {key}. {desc}")
        print()

        choice = input("Выберите операцию: ").strip()
        if choice == '0':
            break
        elif choice == '16':
            deg_mode = not deg_mode
            continue
        elif choice == '15':
            cls(1)
            print("Константы:")
            print("  p - число π (пи)")
            print("  e - число e")
            const = input("Выберите константу: ").strip().lower()
            if const == 'p':
                print_result("π =", value=math.pi)
            elif const == 'e':
                print_result("e =", value=math.e)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        try:
            if choice in ('11', '12'):
                x = safe_float_input("Введите x: ")
                y = safe_float_input("Введите y: ")
            else:
                x = safe_float_input("Введите x: ")
        except Exception as e:
            print(Fore.RED + "Ошибка ввода: " + str(e) + Style.RESET_ALL)
            t(1.5)
            continue

        result = None
        error = None

        try:
            if choice == '1':
                result = math.sin(to_radians(x))
            elif choice == '2':
                result = math.cos(to_radians(x))
            elif choice == '3':
                result = math.tan(to_radians(x))
            elif choice == '4':
                if x < -1 or x > 1:
                    error = "Аргумент должен быть в [-1, 1]"
                else:
                    result = from_radians(math.asin(x))
            elif choice == '5':
                if x < -1 or x > 1:
                    error = "Аргумент должен быть в [-1, 1]"
                else:
                    result = from_radians(math.acos(x))
            elif choice == '6':
                result = from_radians(math.atan(x))
            elif choice == '7':
                if x < 0:
                    error = "Аргумент должен быть неотрицательным"
                else:
                    result = math.sqrt(x)
            elif choice == '8':
                if x <= 0:
                    error = "Аргумент должен быть положительным"
                else:
                    result = math.log10(x)
            elif choice == '9':
                if x <= 0:
                    error = "Аргумент должен быть положительным"
                else:
                    result = math.log(x)
            elif choice == '10':
                result = math.exp(x)
            elif choice == '11':
                result = math.pow(x, y)
            elif choice == '12':
                if x <= 0 or y <= 0 or y == 1:
                    error = "Аргументы должны быть положительными, основание не равно 1"
                else:
                    result = math.log(x, y)
            elif choice == '13':
                result = abs(x)
            elif choice == '14':
                if x < 0 or x != int(x):
                    error = "Факториал определён только для целых неотрицательных чисел"
                else:
                    result = math.factorial(int(x))
            else:
                error = "Неизвестная операция"
        except Exception as e:
            error = str(e)

        if error:
            print(Fore.RED + "Ошибка: " + error + Style.RESET_ALL)
        else:
            if result is not None:
                # Проверяем, близко ли к целому
                if isinstance(result, float) and abs(result - round(result)) < 1e-10:
                    result = round(result)
                print_result("Результат:", value=result)
        t(1.5)

def solve_equations():
    """Решение уравнений: линейных (с выбором операции) и квадратных."""
    while True:
        cls(1)
        print_header("         РЕШЕНИЕ УРАВНЕНИЙ         ")
        print("Выберите тип уравнения:")
        menu = {
            '1': 'Линейное уравнение: a · x ? b = c',
            '2': 'Квадратное уравнение: a·x² + b·x + c = d',
            '0': 'Назад в главное меню'
        }
        for key, desc in menu.items():
            print(f"  {key}. {desc}")
        print()

        choice = input("Выберите действие: ").strip()

        if choice == '0':
            break
        elif choice == '1':
            cls(1)
            print_header("         ЛИНЕЙНОЕ УРАВНЕНИЕ a · x ? b = c         ")
            a = safe_float_input("Введите коэффициент a: ")
            op = input("Выберите операцию (+, -, *, /) между a·x и b: ").strip()
            while op not in ('+', '-', '*', '/'):
                print(Fore.RED + "Ошибка: неверная операция." + Style.RESET_ALL)
                op = input("Выберите операцию (+, -, *, /): ").strip()
            b = safe_float_input("Введите коэффициент b: ")
            c = safe_float_input("Введите правую часть c: ")

            if a == 0:
                if op == '+':
                    lhs = b
                elif op == '-':
                    lhs = -b
                elif op == '*':
                    lhs = 0
                elif op == '/':
                    if b == 0:
                        print(Fore.RED + "Ошибка: деление нуля на ноль." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    lhs = 0
                if abs(lhs - c) < 1e-12:
                    print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                else:
                    print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                t(1.5)
                continue

            try:
                if op == '+':
                    x = (c - b) / a
                elif op == '-':
                    x = (c + b) / a
                elif op == '*':
                    if b == 0:
                        if abs(c) < 1e-12:
                            print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                        else:
                            print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    x = c / (a * b)
                elif op == '/':
                    if b == 0:
                        print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
                        t(1.5)
                        continue
                    x = c * b / a
            except ZeroDivisionError:
                print(Fore.RED + "Ошибка: деление на ноль." + Style.RESET_ALL)
                t(1.5)
                continue

            if abs(x - round(x)) < 1e-10:
                x = round(x)
            print_result("Корень уравнения:", value=x)
            t(1.5)

        elif choice == '2':
            cls(1)
            print_header("         КВАДРАТНОЕ УРАВНЕНИЕ a·x² + b·x + c = d         ")
            a = safe_float_input("Введите коэффициент a: ")
            b = safe_float_input("Введите коэффициент b: ")
            c = safe_float_input("Введите коэффициент c: ")
            d = safe_float_input("Введите правую часть d: ")

            c_adj = c - d

            if abs(a) < 1e-12:
                print(Fore.YELLOW + "Коэффициент a = 0, уравнение становится линейным." + Style.RESET_ALL)
                if abs(b) < 1e-12:
                    if abs(c_adj) < 1e-12:
                        print(Fore.GREEN + "Уравнение имеет бесконечно много решений." + Style.RESET_ALL)
                    else:
                        print(Fore.RED + "Уравнение не имеет решений." + Style.RESET_ALL)
                else:
                    x = -c_adj / b
                    if abs(x - round(x)) < 1e-10:
                        x = round(x)
                    print_result("Корень уравнения:", value=x)
            else:
                D = b**2 - 4*a*c_adj
                print(Fore.CYAN + f"Дискриминант D = {D}" + Style.RESET_ALL)

                if D < -1e-12:
                    print(Fore.RED + "Действительных корней нет." + Style.RESET_ALL)
                elif abs(D) < 1e-12:
                    x = -b / (2*a)
                    if abs(x - round(x)) < 1e-10:
                        x = round(x)
                    print_result("Один корень (два совпадающих):", value=x)
                else:
                    sqrt_D = math.sqrt(D)
                    x1 = (-b + sqrt_D) / (2*a)
                    x2 = (-b - sqrt_D) / (2*a)
                    if abs(x1 - round(x1)) < 1e-10:
                        x1 = round(x1)
                    if abs(x2 - round(x2)) < 1e-10:
                        x2 = round(x2)
                    print(" " * RESULT_INDENT + "Корни уравнения:")
                    print(" " * (RESULT_INDENT+2) + f"x₁ = {x1}")
                    print(" " * (RESULT_INDENT+2) + f"x₂ = {x2}")
            t(1.5)
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)

def systems_of_equations():
    """Решение системы двух линейных уравнений с двумя неизвестными."""
    while True:
        cls(1)
        print_header("         СИСТЕМА ЛИНЕЙНЫХ УРАВНЕНИЙ 2x2         ")
        print("Формат: a1*x + b1*y = c1")
        print("        a2*x + b2*y = c2")
        print()
        try:
            a1 = safe_float_input("Введите a1: ")
            b1 = safe_float_input("Введите b1: ")
            c1 = safe_float_input("Введите c1: ")
            a2 = safe_float_input("Введите a2: ")
            b2 = safe_float_input("Введите b2: ")
            c2 = safe_float_input("Введите c2: ")
        except Exception as e:
            print(Fore.RED + "Ошибка ввода: " + str(e) + Style.RESET_ALL)
            t(1.5)
            break

        # Определители
        det = a1 * b2 - a2 * b1
        det_x = c1 * b2 - c2 * b1
        det_y = a1 * c2 - a2 * c1

        if abs(det) < 1e-12:
            if abs(det_x) < 1e-12 and abs(det_y) < 1e-12:
                print(Fore.GREEN + "Система имеет бесконечно много решений (зависимые уравнения)." + Style.RESET_ALL)
            else:
                print(Fore.RED + "Система не имеет решений (противоречива)." + Style.RESET_ALL)
        else:
            x = det_x / det
            y = det_y / det
            if abs(x - round(x)) < 1e-10:
                x = round(x)
            if abs(y - round(y)) < 1e-10:
                y = round(y)
            print(" " * RESULT_INDENT + "Решение:")
            print(" " * (RESULT_INDENT+2) + f"x = {x}")
            print(" " * (RESULT_INDENT+2) + f"y = {y}")

        t(2)
        print()
        again = input("Решить ещё одну систему? (y/n): ").strip().lower()
        if again != 'y':
            break

def statistics_calculator():
    """Статистические расчёты для списка чисел."""
    while True:
        cls(1)
        print_header("         СТАТИСТИЧЕСКИЙ КАЛЬКУЛЯТОР         ")
        print("Введите числа, разделённые пробелами (например: 1 2 3 4 5):")
        line = input("> ").strip()
        try:
            numbers = list(map(float, line.split()))
            if len(numbers) == 0:
                print(Fore.RED + "Список пуст." + Style.RESET_ALL)
                t(1.5)
                break
        except:
            print(Fore.RED + "Ошибка при разборе чисел." + Style.RESET_ALL)
            t(1.5)
            break

        n = len(numbers)
        mean = statistics.mean(numbers)
        median = statistics.median(numbers)
        try:
            mode = statistics.mode(numbers)
        except statistics.StatisticsError:
            mode = "нет единственной моды"
        variance = statistics.variance(numbers) if n > 1 else 0
        stdev = statistics.stdev(numbers) if n > 1 else 0
        min_val = min(numbers)
        max_val = max(numbers)
        total = sum(numbers)
        # Дополнительные статистики
        numbers_sorted = sorted(numbers)
        q1 = numbers_sorted[n//4] if n>=4 else "недостаточно данных"
        q3 = numbers_sorted[3*n//4] if n>=4 else "недостаточно данных"
        iqr = q3 - q1 if isinstance(q1, float) and isinstance(q3, float) else "?"
        range_val = max_val - min_val

        print(" " * RESULT_INDENT + "Результаты:")
        print(" " * (RESULT_INDENT+2) + f"Количество чисел: {n}")
        print(" " * (RESULT_INDENT+2) + f"Сумма: {total}")
        print(" " * (RESULT_INDENT+2) + f"Среднее арифметическое: {mean}")
        print(" " * (RESULT_INDENT+2) + f"Медиана: {median}")
        print(" " * (RESULT_INDENT+2) + f"Мода: {mode}")
        print(" " * (RESULT_INDENT+2) + f"Дисперсия (выборочная): {variance}")
        print(" " * (RESULT_INDENT+2) + f"Стандартное отклонение: {stdev}")
        print(" " * (RESULT_INDENT+2) + f"Минимум: {min_val}")
        print(" " * (RESULT_INDENT+2) + f"Максимум: {max_val}")
        print(" " * (RESULT_INDENT+2) + f"Размах: {range_val}")
        if n >= 4:
            print(" " * (RESULT_INDENT+2) + f"Первый квартиль (Q1): {q1}")
            print(" " * (RESULT_INDENT+2) + f"Третий квартиль (Q3): {q3}")
            print(" " * (RESULT_INDENT+2) + f"Межквартильный размах (IQR): {iqr}")

        t(2)
        again = input("\nВыполнить другой расчёт? (y/n): ").strip().lower()
        if again != 'y':
            break

def percentage_calculator():
    """Калькулятор процентов."""
    while True:
        cls(1)
        print_header("         КАЛЬКУЛЯТОР ПРОЦЕНТОВ         ")
        print("Выберите операцию:")
        print("  1. Найти процент от числа")
        print("  2. Сколько процентов составляет одно число от другого")
        print("  3. Прибавить процент к числу")
        print("  4. Вычесть процент из числа")
        print("  5. Процентное изменение (от старого к новому)")
        print("  0. Назад")
        choice = input("Ваш выбор: ").strip()

        if choice == '0':
            break

        try:
            if choice == '1':
                num = safe_float_input("Введите число: ")
                percent = safe_float_input("Введите процент: ")
                result = num * percent / 100
                print_result(f"{percent}% от {num} =", value=result)
            elif choice == '2':
                part = safe_float_input("Введите часть (числитель): ")
                whole = safe_float_input("Введите целое (знаменатель): ")
                if whole == 0:
                    print(Fore.RED + "Ошибка: знаменатель не может быть нулём." + Style.RESET_ALL)
                else:
                    percent = part / whole * 100
                    if abs(percent - round(percent)) < 1e-10:
                        percent = round(percent)
                    print_result(f"{part} от {whole} составляет", value=f"{percent}%")
            elif choice == '3':
                num = safe_float_input("Введите число: ")
                percent = safe_float_input("Введите процент: ")
                result = num * (1 + percent/100)
                print_result(f"Результат после прибавления {percent}%:", value=result)
            elif choice == '4':
                num = safe_float_input("Введите число: ")
                percent = safe_float_input("Введите процент: ")
                result = num * (1 - percent/100)
                print_result(f"Результат после вычитания {percent}%:", value=result)
            elif choice == '5':
                old = safe_float_input("Введите старое значение: ")
                new = safe_float_input("Введите новое значение: ")
                if old == 0:
                    print(Fore.RED + "Старое значение не может быть нулём." + Style.RESET_ALL)
                else:
                    change = (new - old) / old * 100
                    if abs(change - round(change)) < 1e-10:
                        change = round(change)
                    print_result("Процентное изменение:", value=f"{change}%")
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить другую операцию с процентами? (y/n): ").strip().lower()
        if again != 'y':
            break

def unit_converter():
    """Конвертер единиц измерения с расширенными категориями."""
    # Словарь коэффициентов перевода в базовую единицу (СИ)
    units = {
        'length': {
            'm': 1, 'km': 1000, 'cm': 0.01, 'mm': 0.001, 'mile': 1609.344,
            'yard': 0.9144, 'foot': 0.3048, 'inch': 0.0254, 'nautical_mile': 1852
        },
        'mass': {
            'kg': 1, 'g': 0.001, 'mg': 1e-6, 'ton': 1000, 'lb': 0.453592,
            'oz': 0.0283495, 'stone': 6.35029
        },
        'time': {
            's': 1, 'min': 60, 'h': 3600, 'day': 86400, 'week': 604800, 'year': 31536000
        },
        'area': {
            'm2': 1, 'km2': 1e6, 'cm2': 0.0001, 'mm2': 1e-6, 'ha': 10000, 'acre': 4046.86
        },
        'volume': {
            'm3': 1, 'l': 0.001, 'ml': 1e-6, 'gal_us': 0.00378541, 'gal_uk': 0.00454609,
            'ft3': 0.0283168, 'in3': 1.6387e-5
        },
        'speed': {
            'm/s': 1, 'km/h': 0.277778, 'mph': 0.44704, 'knot': 0.514444
        },
        'pressure': {
            'pa': 1, 'kpa': 1000, 'bar': 100000, 'atm': 101325, 'psi': 6894.76
        },
        'energy': {
            'j': 1, 'kj': 1000, 'cal': 4.184, 'kcal': 4184, 'wh': 3600, 'kwh': 3.6e6
        },
        'temperature': 'special',  # особый случай
        'data': {  # единицы информации
            'b': 1, 'B': 8, 'kb': 1024, 'KB': 8192, 'mb': 1048576, 'MB': 8388608,
            'gb': 1073741824, 'GB': 8589934592, 'tb': 1099511627776, 'TB': 8796093022208
        }
    }

    def convert_temperature(value, from_unit, to_unit):
        if from_unit == 'C':
            if to_unit == 'C':
                return value
            elif to_unit == 'F':
                return value * 9/5 + 32
            elif to_unit == 'K':
                return value + 273.15
        elif from_unit == 'F':
            if to_unit == 'F':
                return value
            elif to_unit == 'C':
                return (value - 32) * 5/9
            elif to_unit == 'K':
                return (value - 32) * 5/9 + 273.15
        elif from_unit == 'K':
            if to_unit == 'K':
                return value
            elif to_unit == 'C':
                return value - 273.15
            elif to_unit == 'F':
                return (value - 273.15) * 9/5 + 32
        raise ValueError("Неверные единицы температуры")

    while True:
        cls(1)
        print_header("         КОНВЕРТЕР ЕДИНИЦ         ")
        print("Выберите категорию:")
        categories = list(units.keys())
        for idx, cat in enumerate(categories, 1):
            print(f"  {idx}. {cat.capitalize()}")
        print("  0. Назад")
        try:
            cat_choice = safe_int_input("Ваш выбор: ")
            if cat_choice == 0:
                break
            if cat_choice < 1 or cat_choice > len(categories):
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
                t(1.5)
                continue
            category = categories[cat_choice-1]
        except:
            print(Fore.RED + "Неверный ввод." + Style.RESET_ALL)
            t(1.5)
            continue

        if category == 'temperature':
            unit_names = ['C', 'F', 'K']
        else:
            unit_names = list(units[category].keys())

        print("Доступные единицы:", ', '.join(unit_names))
        value = safe_float_input("Введите значение: ")
        from_unit = input("Из какой единицы? ").strip().lower()
        to_unit = input("В какую единицу? ").strip().lower()

        if from_unit not in unit_names or to_unit not in unit_names:
            print(Fore.RED + "Неверные единицы измерения." + Style.RESET_ALL)
            t(1.5)
            continue

        try:
            if category == 'temperature':
                result = convert_temperature(value, from_unit.upper(), to_unit.upper())
            else:
                # Переводим в базовую единицу, затем в целевую
                base_value = value * units[category][from_unit]
                result = base_value / units[category][to_unit]
            # Округление до разумного
            if abs(result - round(result)) < 1e-10:
                result = round(result)
            else:
                result = round(result, 10)  # убираем лишние знаки
            print_result(f"{value} {from_unit} =", value=f"{result} {to_unit}")
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить ещё одну конвертацию? (y/n): ").strip().lower()
        if again != 'y':
            break

def base_converter():
    """Конвертер систем счисления (2,8,10,16) и произвольных до 36."""
    digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    def to_base(num, base):
        if num == 0:
            return '0'
        res = ''
        n = abs(num)
        while n > 0:
            res = digits[n % base] + res
            n //= base
        if num < 0:
            res = '-' + res
        return res

    while True:
        cls(1)
        print_header("         КОНВЕРТЕР СИСТЕМ СЧИСЛЕНИЯ         ")
        print("Поддерживаемые системы: от 2 до 36.")
        try:
            num_str = input("Введите число: ").strip()
            from_base = safe_int_input("Из какой системы (2-36)? ")
            if from_base < 2 or from_base > 36:
                print(Fore.RED + "Основание должно быть от 2 до 36." + Style.RESET_ALL)
                t(1.5)
                continue
            to_base_val = safe_int_input("В какую систему (2-36)? ")
            if to_base_val < 2 or to_base_val > 36:
                print(Fore.RED + "Основание должно быть от 2 до 36." + Style.RESET_ALL)
                t(1.5)
                continue
        except:
            print(Fore.RED + "Ошибка ввода." + Style.RESET_ALL)
            t(1.5)
            continue

        try:
            if from_base == 10:
                num = int(num_str)
            else:
                num = int(num_str, from_base)
        except ValueError:
            print(Fore.RED + "Ошибка: неверное число для данной системы." + Style.RESET_ALL)
            t(1.5)
            continue

        result = to_base(num, to_base_val)
        print_result(f"Результат в системе {to_base_val}:", value=result)

        t(1.5)
        again = input("\nКонвертировать ещё одно число? (y/n): ").strip().lower()
        if again != 'y':
            break

# ========== НОВЫЕ ФУНКЦИИ (ДОПОЛНИТЕЛЬНЫЕ) ==========

def complex_calculator():
    """Калькулятор комплексных чисел."""
    while True:
        cls(1)
        print_header("         КАЛЬКУЛЯТОР КОМПЛЕКСНЫХ ЧИСЕЛ         ")
        print("Выберите операцию:")
        print("  1. Сложение")
        print("  2. Вычитание")
        print("  3. Умножение")
        print("  4. Деление")
        print("  5. Модуль")
        print("  6. Аргумент (фаза)")
        print("  7. Сопряжённое")
        print("  8. Квадратный корень")
        print("  9. Возведение в степень (целую)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        if op in ('1','2','3','4','9'):
            z1 = safe_complex_input("Введите первое комплексное число (a+bj): ")
            if op != '9':
                z2 = safe_complex_input("Введите второе комплексное число: ")
            else:
                n = safe_int_input("Введите целую степень: ")
        elif op in ('5','6','7','8'):
            z = safe_complex_input("Введите комплексное число: ")
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        try:
            if op == '1':
                res = z1 + z2
            elif op == '2':
                res = z1 - z2
            elif op == '3':
                res = z1 * z2
            elif op == '4':
                res = z1 / z2
            elif op == '5':
                res = abs(z)
            elif op == '6':
                res = cmath.phase(z)
                if abs(res - round(res, 10)) < 1e-10:
                    res = round(res, 10)
            elif op == '7':
                res = z.conjugate()
            elif op == '8':
                res = cmath.sqrt(z)
            elif op == '9':
                res = z1 ** n
            else:
                continue

            print_result("Результат:", value=res)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def matrix_calculator():
    """Матричный калькулятор (2x2 и 3x3)."""
    def input_matrix(size):
        print(f"Введите элементы матрицы {size}x{size} построчно:")
        mat = []
        for i in range(size):
            row = []
            for j in range(size):
                val = safe_float_input(f"  Элемент [{i+1},{j+1}]: ")
                row.append(val)
            mat.append(row)
        return mat

    def print_matrix(mat, indent=0):
        for row in mat:
            print(" " * indent + " ".join(f"{x:10.4f}" for x in row))

    def mat_det2(mat):
        return mat[0][0]*mat[1][1] - mat[0][1]*mat[1][0]

    def mat_det3(mat):
        a = mat[0][0]; b = mat[0][1]; c = mat[0][2]
        d = mat[1][0]; e = mat[1][1]; f = mat[1][2]
        g = mat[2][0]; h = mat[2][1]; i = mat[2][2]
        return a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g)

    def mat_inv2(mat):
        det = mat_det2(mat)
        if abs(det) < 1e-12:
            raise ValueError("Матрица вырождена, обратной нет.")
        return [[mat[1][1]/det, -mat[0][1]/det],
                [-mat[1][0]/det, mat[0][0]/det]]

    def mat_inv3(mat):
        det = mat_det3(mat)
        if abs(det) < 1e-12:
            raise ValueError("Матрица вырождена, обратной нет.")
        # Миноры
        a = mat[0][0]; b = mat[0][1]; c = mat[0][2]
        d = mat[1][0]; e = mat[1][1]; f = mat[1][2]
        g = mat[2][0]; h = mat[2][1]; i = mat[2][2]
        inv = [[0]*3 for _ in range(3)]
        inv[0][0] = (e*i - f*h) / det
        inv[0][1] = (c*h - b*i) / det
        inv[0][2] = (b*f - c*e) / det
        inv[1][0] = (f*g - d*i) / det
        inv[1][1] = (a*i - c*g) / det
        inv[1][2] = (c*d - a*f) / det
        inv[2][0] = (d*h - e*g) / det
        inv[2][1] = (b*g - a*h) / det
        inv[2][2] = (a*e - b*d) / det
        return inv

    def mat_mul(A, B):
        n = len(A)
        C = [[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]
        return C

    while True:
        cls(1)
        print_header("         МАТРИЧНЫЙ КАЛЬКУЛЯТОР         ")
        print("Выберите размер матрицы:")
        print("  1. 2x2")
        print("  2. 3x3")
        print("  0. Назад")
        sz = input("Ваш выбор: ").strip()
        if sz == '0':
            break
        elif sz == '1':
            size = 2
        elif sz == '2':
            size = 3
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        print("Выберите операцию:")
        print("  1. Определитель")
        print("  2. Транспонирование")
        print("  3. Обратная матрица")
        print("  4. Сложение")
        print("  5. Умножение")
        op = input("Ваш выбор: ").strip()
        if op not in ('1','2','3','4','5'):
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        A = input_matrix(size)
        if op in ('4','5'):
            B = input_matrix(size)

        try:
            if op == '1':
                det = mat_det2(A) if size == 2 else mat_det3(A)
                print_result("Определитель =", value=det)
            elif op == '2':
                T = [[A[j][i] for j in range(size)] for i in range(size)]
                print("Транспонированная матрица:")
                print_matrix(T, RESULT_INDENT)
            elif op == '3':
                inv = mat_inv2(A) if size == 2 else mat_inv3(A)
                print("Обратная матрица:")
                print_matrix(inv, RESULT_INDENT)
            elif op == '4':
                C = [[A[i][j] + B[i][j] for j in range(size)] for i in range(size)]
                print("Сумма матриц:")
                print_matrix(C, RESULT_INDENT)
            elif op == '5':
                C = mat_mul(A, B)
                print("Произведение матриц:")
                print_matrix(C, RESULT_INDENT)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить ещё одну операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def financial_calculator():
    """Финансовый калькулятор."""
    while True:
        cls(1)
        print_header("         ФИНАНСОВЫЙ КАЛЬКУЛЯТОР         ")
        print("Выберите операцию:")
        print("  1. Простые проценты")
        print("  2. Сложные проценты")
        print("  3. Будущая стоимость (FV)")
        print("  4. Текущая стоимость (PV)")
        print("  5. Периодический платёж (аннуитет)")
        print("  6. Расчёт кредита (ежемесячный платёж)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                P = safe_float_input("Введите начальную сумму (P): ")
                r = safe_float_input("Введите процентную ставку за период (%, например 5): ")
                n = safe_float_input("Введите количество периодов: ")
                I = P * r/100 * n
                A = P + I
                print_result("Наращённая сумма (простые %):", value=A)
            elif op == '2':
                P = safe_float_input("Введите начальную сумму (P): ")
                r = safe_float_input("Введите годовую ставку (%, например 5): ")
                n = safe_float_input("Введите количество лет: ")
                m = safe_int_input("Количество начислений в год (1,4,12,...): ")
                A = P * (1 + (r/100)/m) ** (m*n)
                print_result("Наращённая сумма (сложные %):", value=A)
            elif op == '3':
                PV = safe_float_input("Введите текущую стоимость (PV): ")
                r = safe_float_input("Введите ставку за период (%): ")
                n = safe_float_input("Введите количество периодов: ")
                FV = PV * (1 + r/100) ** n
                print_result("Будущая стоимость (FV):", value=FV)
            elif op == '4':
                FV = safe_float_input("Введите будущую стоимость (FV): ")
                r = safe_float_input("Введите ставку за период (%): ")
                n = safe_float_input("Введите количество периодов: ")
                PV = FV / (1 + r/100) ** n
                print_result("Текущая стоимость (PV):", value=PV)
            elif op == '5':
                P = safe_float_input("Введите сумму кредита/инвестиции: ")
                r = safe_float_input("Введите ставку за период (%): ")
                n = safe_float_input("Введите количество периодов: ")
                PMT = P * (r/100) / (1 - (1 + r/100)**-n)
                print_result("Периодический платёж (PMT):", value=PMT)
            elif op == '6':
                S = safe_float_input("Введите сумму кредита: ")
                r_year = safe_float_input("Введите годовую ставку (%): ")
                years = safe_float_input("Введите срок (лет): ")
                m = safe_int_input("Количество платежей в год (обычно 12): ")
                r_period = r_year/100/m
                n_periods = years*m
                PMT = S * r_period / (1 - (1 + r_period)**-n_periods)
                total = PMT * n_periods
                print_result("Ежемесячный платёж:", value=PMT)
                print_result("Общая сумма выплат:", value=total)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить другой расчёт? (y/n): ").strip().lower()
        if again != 'y':
            break

def numeric_integration():
    """Численное интегрирование (метод трапеций и Симпсона)."""
    # Предопределённые функции
    functions = {
        '1': ('sin(x)', math.sin),
        '2': ('cos(x)', math.cos),
        '3': ('exp(x)', math.exp),
        '4': ('x^2', lambda x: x**2),
        '5': ('x^3', lambda x: x**3),
        '6': ('sqrt(x)', lambda x: math.sqrt(x) if x>=0 else float('nan')),
        '7': ('ln(x)', lambda x: math.log(x) if x>0 else float('nan')),
    }

    while True:
        cls(1)
        print_header("         ЧИСЛЕННОЕ ИНТЕГРИРОВАНИЕ         ")
        print("Выберите функцию:")
        for key, (desc, _) in functions.items():
            print(f"  {key}. {desc}")
        print("  0. Назад")
        f_choice = input("Ваш выбор: ").strip()
        if f_choice == '0':
            break
        if f_choice not in functions:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue
        func = functions[f_choice][1]

        a = safe_float_input("Введите нижний предел a: ")
        b = safe_float_input("Введите верхний предел b: ")
        if a > b:
            a, b = b, a
            print(Fore.YELLOW + "Пределы поменяны местами." + Style.RESET_ALL)
        n = safe_int_input("Введите количество разбиений (целое >0): ")
        if n <= 0:
            print(Fore.RED + "Число разбиений должно быть положительным." + Style.RESET_ALL)
            t(1.5)
            continue

        h = (b - a) / n
        # Метод трапеций
        x = [a + i*h for i in range(n+1)]
        try:
            y = [func(xi) for xi in x]
        except Exception as e:
            print(Fore.RED + "Ошибка вычисления функции: " + str(e) + Style.RESET_ALL)
            t(1.5)
            continue

        trapezoid = h * (0.5*y[0] + 0.5*y[-1] + sum(y[1:-1]))
        # Метод Симпсона (требует чётное n)
        if n % 2 == 0:
            simpson = h/3 * (y[0] + y[-1] + 4*sum(y[1:-1:2]) + 2*sum(y[2:-1:2]))
        else:
            simpson = "неприменимо (n должно быть чётным)"

        print_result("Метод трапеций:", value=trapezoid)
        print_result("Метод Симпсона:", value=simpson)

        t(1.5)
        again = input("\nВыполнить другой расчёт? (y/n): ").strip().lower()
        if again != 'y':
            break

def nonlinear_solver():
    """Решение нелинейных уравнений (метод бисекции и Ньютона)."""
    # Предопределённые функции
    functions = {
        '1': ('x^2 - 2', lambda x: x**2 - 2, lambda x: 2*x),
        '2': ('sin(x) - 0.5', lambda x: math.sin(x) - 0.5, lambda x: math.cos(x)),
        '3': ('exp(x) - 2', lambda x: math.exp(x) - 2, lambda x: math.exp(x)),
        '4': ('ln(x)', lambda x: math.log(x) if x>0 else float('nan'), lambda x: 1/x),
        '5': ('x^3 - x - 1', lambda x: x**3 - x - 1, lambda x: 3*x**2 - 1),
    }

    while True:
        cls(1)
        print_header("         РЕШЕНИЕ НЕЛИНЕЙНЫХ УРАВНЕНИЙ         ")
        print("Выберите функцию f(x)=0:")
        for key, (desc, _, _) in functions.items():
            print(f"  {key}. {desc}")
        print("  0. Назад")
        f_choice = input("Ваш выбор: ").strip()
        if f_choice == '0':
            break
        if f_choice not in functions:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue
        f, df = functions[f_choice][1], functions[f_choice][2]

        print("Выберите метод:")
        print("  1. Метод бисекции")
        print("  2. Метод Ньютона")
        method = input("Ваш выбор: ").strip()

        try:
            if method == '1':
                a = safe_float_input("Введите левую границу интервала [a,b]: ")
                b = safe_float_input("Введите правую границу интервала: ")
                eps = safe_float_input("Введите точность (например 1e-6): ")
                max_iter = safe_int_input("Введите максимальное число итераций: ")
                fa = f(a)
                fb = f(b)
                if fa * fb >= 0:
                    print(Fore.RED + "Функция должна иметь разные знаки на концах интервала." + Style.RESET_ALL)
                    t(1.5)
                    continue
                for i in range(max_iter):
                    c = (a + b) / 2
                    fc = f(c)
                    if abs(fc) < eps or (b - a)/2 < eps:
                        print_result(f"Корень найден за {i+1} итераций:", value=c)
                        break
                    if fa * fc < 0:
                        b = c
                        fb = fc
                    else:
                        a = c
                        fa = fc
                else:
                    print(Fore.RED + "Достигнуто максимальное число итераций." + Style.RESET_ALL)
            elif method == '2':
                x0 = safe_float_input("Введите начальное приближение: ")
                eps = safe_float_input("Введите точность (например 1e-6): ")
                max_iter = safe_int_input("Введите максимальное число итераций: ")
                x = x0
                for i in range(max_iter):
                    fx = f(x)
                    dfx = df(x)
                    if abs(dfx) < 1e-12:
                        print(Fore.RED + "Производная близка к нулю, метод Ньютона не сходится." + Style.RESET_ALL)
                        break
                    x_new = x - fx / dfx
                    if abs(x_new - x) < eps:
                        print_result(f"Корень найден за {i+1} итераций:", value=x_new)
                        break
                    x = x_new
                else:
                    print(Fore.RED + "Достигнуто максимальное число итераций." + Style.RESET_ALL)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nРешить другое уравнение? (y/n): ").strip().lower()
        if again != 'y':
            break

def random_generator():
    """Генератор случайных чисел."""
    while True:
        cls(1)
        print_header("         ГЕНЕРАТОР СЛУЧАЙНЫХ ЧИСЕЛ         ")
        print("Выберите тип генерации:")
        print("  1. Целое число в диапазоне [a, b]")
        print("  2. Вещественное число в [a, b]")
        print("  3. Случайный элемент из списка (через запятую)")
        print("  4. Перемешать список")
        print("  5. Нормальное распределение (мю, сигма)")
        print("  6. Случайная строка заданной длины (из букв и цифр)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                a = safe_int_input("Введите нижнюю границу a: ")
                b = safe_int_input("Введите верхнюю границу b: ")
                if a > b:
                    a, b = b, a
                res = random.randint(a, b)
                print_result("Случайное целое:", value=res)
            elif op == '2':
                a = safe_float_input("Введите нижнюю границу a: ")
                b = safe_float_input("Введите верхнюю границу b: ")
                if a > b:
                    a, b = b, a
                res = random.uniform(a, b)
                print_result("Случайное вещественное:", value=res)
            elif op == '3':
                lst_str = input("Введите элементы через запятую: ")
                items = [x.strip() for x in lst_str.split(',')]
                if items:
                    res = random.choice(items)
                    print_result("Случайный элемент:", value=res)
                else:
                    print(Fore.RED + "Список пуст." + Style.RESET_ALL)
            elif op == '4':
                lst_str = input("Введите элементы через запятую: ")
                items = [x.strip() for x in lst_str.split(',')]
                if items:
                    random.shuffle(items)
                    print("Перемешанный список: " + ', '.join(items))
                else:
                    print(Fore.RED + "Список пуст." + Style.RESET_ALL)
            elif op == '5':
                mu = safe_float_input("Введите среднее (мю): ")
                sigma = safe_float_input("Введите стандартное отклонение (сигма): ")
                res = random.gauss(mu, sigma)
                print_result("Случайное число (норм. распр.):", value=res)
            elif op == '6':
                length = safe_int_input("Введите длину строки: ")
                chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                res = ''.join(random.choice(chars) for _ in range(length))
                print_result("Случайная строка:", value=res)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nСгенерировать ещё? (y/n): ").strip().lower()
        if again != 'y':
            break

def date_time_calculator():
    """Калькулятор дат и времени."""
    while True:
        cls(1)
        print_header("         КАЛЬКУЛЯТОР ДАТ И ВРЕМЕНИ         ")
        print("Выберите операцию:")
        print("  1. Разница между датами (в днях)")
        print("  2. Прибавить дни к дате")
        print("  3. Разница между временем (в часах, минутах)")
        print("  4. Сложить временные интервалы")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                d1_str = input("Введите первую дату (ГГГГ-ММ-ДД): ")
                d2_str = input("Введите вторую дату: ")
                d1 = datetime.datetime.strptime(d1_str, "%Y-%m-%d").date()
                d2 = datetime.datetime.strptime(d2_str, "%Y-%m-%d").date()
                delta = abs((d2 - d1).days)
                print_result("Разница в днях:", value=delta)
            elif op == '2':
                d_str = input("Введите дату (ГГГГ-ММ-ДД): ")
                days = safe_int_input("Сколько дней прибавить? ")
                d = datetime.datetime.strptime(d_str, "%Y-%m-%d").date()
                new_d = d + datetime.timedelta(days=days)
                print_result("Новая дата:", value=new_d.strftime("%Y-%m-%d"))
            elif op == '3':
                t1_str = input("Введите первое время (ЧЧ:ММ): ")
                t2_str = input("Введите второе время (ЧЧ:ММ): ")
                fmt = "%H:%M"
                t1 = datetime.datetime.strptime(t1_str, fmt)
                t2 = datetime.datetime.strptime(t2_str, fmt)
                delta = abs(t2 - t1)
                hours = delta.seconds // 3600
                minutes = (delta.seconds % 3600) // 60
                print_result("Разница:", value=f"{hours} ч {minutes} мин")
            elif op == '4':
                h1 = safe_int_input("Часы первого интервала: ")
                m1 = safe_int_input("Минуты первого интервала: ")
                h2 = safe_int_input("Часы второго интервала: ")
                m2 = safe_int_input("Минуты второго интервала: ")
                total_min = (h1+h2)*60 + (m1+m2)
                h = total_min // 60
                m = total_min % 60
                print_result("Сумма интервалов:", value=f"{h} ч {m} мин")
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def cubic_equation_solver():
    """Решение кубического уравнения a*x^3 + b*x^2 + c*x + d = 0."""
    cls(1)
    print_header("         КУБИЧЕСКОЕ УРАВНЕНИЕ a·x³ + b·x² + c·x + d = 0         ")
    try:
        a = safe_float_input("Введите коэффициент a: ")
        b = safe_float_input("Введите коэффициент b: ")
        c = safe_float_input("Введите коэффициент c: ")
        d = safe_float_input("Введите коэффициент d: ")
    except:
        return

    if abs(a) < 1e-12:
        print(Fore.YELLOW + "Коэффициент a = 0, решается как квадратное." + Style.RESET_ALL)
        # решаем квадратное
        D = b**2 - 4*a*c
        if abs(D) < 1e-12:
            x = -b/(2*a)
            print_result("Один корень:", value=x)
        elif D > 0:
            x1 = (-b + math.sqrt(D))/(2*a)
            x2 = (-b - math.sqrt(D))/(2*a)
            print_result("Корни:", value=[x1, x2])
        else:
            print(Fore.RED + "Комплексные корни (не реализовано)." + Style.RESET_ALL)
        return

    # Приведение к нормализованному виду x^3 + px + q = 0
    p = (3*a*c - b**2) / (3*a**2)
    q = (2*b**3 - 9*a*b*c + 27*a**2*d) / (27*a**3)
    Q = (p/3)**3 + (q/2)**2
    if Q >= 0:
        # один действительный корень
        alpha = (-q/2 + math.sqrt(Q))**(1/3)
        beta = (-q/2 - math.sqrt(Q))**(1/3)
        x1 = alpha + beta - b/(3*a)
        print_result("Действительный корень:", value=x1)
    else:
        # три действительных корня
        r = math.sqrt((-p/3)**3)
        phi = math.acos(-q/(2*r))
        r = 2*math.cbrt(r)
        x1 = r * math.cos(phi/3) - b/(3*a)
        x2 = r * math.cos((phi + 2*math.pi)/3) - b/(3*a)
        x3 = r * math.cos((phi + 4*math.pi)/3) - b/(3*a)
        print_result("Три корня:", value=[x1, x2, x3])

    t(2)

def vector_calculator():
    """Операции с векторами (2D и 3D)."""
    while True:
        cls(1)
        print_header("         ВЕКТОРНЫЙ КАЛЬКУЛЯТОР         ")
        print("Выберите размерность:")
        print("  1. 2D")
        print("  2. 3D")
        print("  0. Назад")
        dim = input("Ваш выбор: ").strip()
        if dim == '0':
            break
        elif dim == '1':
            size = 2
        elif dim == '2':
            size = 3
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)
            continue

        print("Выберите операцию:")
        print("  1. Сложение")
        print("  2. Вычитание")
        print("  3. Скалярное произведение")
        print("  4. Векторное произведение (только 3D)")
        print("  5. Длина (модуль)")
        print("  6. Умножение на скаляр")
        print("  7. Нормализация")
        print("  8. Угол между векторами (в градусах)")
        op = input("Ваш выбор: ").strip()

        def input_vector(n):
            return [safe_float_input(f"Введите координату {i+1}: ") for i in range(n)]

        try:
            if op in ('1','2','3','4','8'):
                print("Вектор A:")
                A = input_vector(size)
                print("Вектор B:")
                B = input_vector(size)
            elif op in ('5','7'):
                print("Вектор A:")
                A = input_vector(size)
            elif op == '6':
                print("Вектор A:")
                A = input_vector(size)
                scalar = safe_float_input("Введите скаляр: ")
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
                t(1.5)
                continue

            if op == '1':
                C = [A[i] + B[i] for i in range(size)]
                print_result("Сумма векторов:", value=C)
            elif op == '2':
                C = [A[i] - B[i] for i in range(size)]
                print_result("Разность (A-B):", value=C)
            elif op == '3':
                dot = sum(A[i]*B[i] for i in range(size))
                print_result("Скалярное произведение:", value=dot)
            elif op == '4':
                if size != 3:
                    print(Fore.RED + "Векторное произведение только для 3D." + Style.RESET_ALL)
                else:
                    cross = [
                        A[1]*B[2] - A[2]*B[1],
                        A[2]*B[0] - A[0]*B[2],
                        A[0]*B[1] - A[1]*B[0]
                    ]
                    print_result("Векторное произведение:", value=cross)
            elif op == '5':
                length = math.sqrt(sum(x**2 for x in A))
                print_result("Длина вектора:", value=length)
            elif op == '6':
                C = [scalar * x for x in A]
                print_result("Результат:", value=C)
            elif op == '7':
                length = math.sqrt(sum(x**2 for x in A))
                if length < 1e-12:
                    print(Fore.RED + "Нулевой вектор нельзя нормализовать." + Style.RESET_ALL)
                else:
                    norm = [x/length for x in A]
                    print_result("Нормализованный вектор:", value=norm)
            elif op == '8':
                dot = sum(A[i]*B[i] for i in range(size))
                lenA = math.sqrt(sum(x**2 for x in A))
                lenB = math.sqrt(sum(x**2 for x in B))
                if lenA*lenB == 0:
                    print(Fore.RED + "Нулевой вектор." + Style.RESET_ALL)
                else:
                    cos = dot / (lenA*lenB)
                    if cos > 1: cos = 1
                    if cos < -1: cos = -1
                    angle = math.degrees(math.acos(cos))
                    print_result("Угол между векторами (градусы):", value=angle)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)

        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def gauss_elimination():
    """Решение систем линейных уравнений методом Гаусса (произвольная размерность)."""
    cls(1)
    print_header("         РЕШЕНИЕ СЛАУ МЕТОДОМ ГАУССА         ")
    try:
        n = safe_int_input("Введите количество уравнений (и неизвестных): ")
        if n <= 0:
            print(Fore.RED + "Размерность должна быть положительной." + Style.RESET_ALL)
            t(1.5)
            return
        # Ввод расширенной матрицы
        A = []
        print("Введите коэффициенты уравнений и правые части:")
        for i in range(n):
            row = []
            for j in range(n+1):
                if j < n:
                    val = safe_float_input(f"a[{i+1},{j+1}] = ")
                else:
                    val = safe_float_input(f"b[{i+1}] = ")
                row.append(val)
            A.append(row)
    except:
        print(Fore.RED + "Ошибка ввода." + Style.RESET_ALL)
        t(1.5)
        return

    # Прямой ход
    for i in range(n):
        # Поиск главного элемента
        max_row = i
        for k in range(i+1, n):
            if abs(A[k][i]) > abs(A[max_row][i]):
                max_row = k
        if abs(A[max_row][i]) < 1e-12:
            print(Fore.RED + "Система вырождена или имеет бесконечно много решений." + Style.RESET_ALL)
            t(1.5)
            return
        A[i], A[max_row] = A[max_row], A[i]

        # Нормализация строки i
        pivot = A[i][i]
        for j in range(i, n+1):
            A[i][j] /= pivot

        # Исключение в нижележащих строках
        for k in range(i+1, n):
            factor = A[k][i]
            for j in range(i, n+1):
                A[k][j] -= factor * A[i][j]

    # Обратный ход
    x = [0]*n
    for i in range(n-1, -1, -1):
        x[i] = A[i][n]
        for j in range(i+1, n):
            x[i] -= A[i][j] * x[j]

    # Вывод
    print(" " * RESULT_INDENT + "Решение:")
    for i in range(n):
        val = x[i]
        if abs(val - round(val)) < 1e-10:
            val = round(val)
        print(" " * (RESULT_INDENT+2) + f"x{i+1} = {val}")
    t(2)

def combinatorics():
    """Комбинаторные функции: перестановки, сочетания, размещения."""
    while True:
        cls(1)
        print_header("         КОМБИНАТОРИКА         ")
        print("Выберите операцию:")
        print("  1. Перестановки P(n) = n!")
        print("  2. Размещения A(n, k) = n! / (n-k)!")
        print("  3. Сочетания C(n, k) = n! / (k!(n-k)!)")
        print("  4. Биномиальные коэффициенты (строка треугольника Паскаля для n)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                n = safe_int_input("Введите n: ")
                if n < 0:
                    print(Fore.RED + "n должно быть неотрицательным." + Style.RESET_ALL)
                else:
                    res = math.factorial(n)
                    print_result(f"P({n}) =", value=res)
            elif op == '2':
                n = safe_int_input("Введите n: ")
                k = safe_int_input("Введите k: ")
                if n < 0 or k < 0 or k > n:
                    print(Fore.RED + "Неверные значения (должны быть 0 ≤ k ≤ n)." + Style.RESET_ALL)
                else:
                    res = math.factorial(n) // math.factorial(n-k)
                    print_result(f"A({n}, {k}) =", value=res)
            elif op == '3':
                n = safe_int_input("Введите n: ")
                k = safe_int_input("Введите k: ")
                if n < 0 or k < 0 or k > n:
                    print(Fore.RED + "Неверные значения (должны быть 0 ≤ k ≤ n)." + Style.RESET_ALL)
                else:
                    res = math.comb(n, k)
                    print_result(f"C({n}, {k}) =", value=res)
            elif op == '4':
                n = safe_int_input("Введите n (номер строки): ")
                if n < 0:
                    print(Fore.RED + "n должно быть неотрицательным." + Style.RESET_ALL)
                else:
                    row = [math.comb(n, k) for k in range(n+1)]
                    print_result(f"Строка {n} треугольника Паскаля:", value=row)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def bitwise_operations():
    """Битовые операции над целыми числами."""
    while True:
        cls(1)
        print_header("         БИТОВЫЕ ОПЕРАЦИИ         ")
        print("Выберите операцию:")
        print("  1. AND (a & b)")
        print("  2. OR (a | b)")
        print("  3. XOR (a ^ b)")
        print("  4. NOT (~a)")
        print("  5. Сдвиг влево (a << b)")
        print("  6. Сдвиг вправо (a >> b)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op in ('1','2','3','5','6'):
                a = safe_int_input("Введите a: ")
                b = safe_int_input("Введите b: ")
                if op == '1':
                    res = a & b
                elif op == '2':
                    res = a | b
                elif op == '3':
                    res = a ^ b
                elif op == '5':
                    res = a << b
                elif op == '6':
                    res = a >> b
                print_result("Результат:", value=res)
                # Двоичное представление
                bin_a = bin(a)[2:] if a>=0 else '-' + bin(-a)[2:]
                bin_b = bin(b)[2:] if b>=0 else '-' + bin(-b)[2:]
                bin_res = bin(res)[2:] if res>=0 else '-' + bin(-res)[2:]
                print(" " * RESULT_INDENT + f"a = {bin_a} (bin)")
                print(" " * RESULT_INDENT + f"b = {bin_b} (bin)")
                print(" " * RESULT_INDENT + f"результат = {bin_res} (bin)")
            elif op == '4':
                a = safe_int_input("Введите a: ")
                res = ~a
                print_result("Результат (~a):", value=res)
                bin_a = bin(a)[2:] if a>=0 else '-' + bin(-a)[2:]
                bin_res = bin(res)[2:] if res>=0 else '-' + bin(-res)[2:]
                print(" " * RESULT_INDENT + f"a = {bin_a} (bin)")
                print(" " * RESULT_INDENT + f"результат = {bin_res} (bin)")
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def prime_numbers():
    """Функции теории чисел: простые числа, разложение на множители, функция Эйлера."""
    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i*i <= n:
            if n % i == 0 or n % (i+2) == 0:
                return False
            i += 6
        return True

    def factorize(n):
        factors = []
        d = 2
        while d*d <= n:
            while n % d == 0:
                factors.append(d)
                n //= d
            d += 1 if d == 2 else 2
        if n > 1:
            factors.append(n)
        return factors

    def euler_phi(n):
        result = n
        p = 2
        while p*p <= n:
            if n % p == 0:
                while n % p == 0:
                    n //= p
                result -= result // p
            p += 1
        if n > 1:
            result -= result // n
        return result

    while True:
        cls(1)
        print_header("         ТЕОРИЯ ЧИСЕЛ         ")
        print("Выберите операцию:")
        print("  1. Проверка числа на простоту")
        print("  2. Разложение на простые множители")
        print("  3. Функция Эйлера φ(n)")
        print("  4. Найти все простые числа до N (решето Эратосфена)")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                n = safe_int_input("Введите число: ")
                if is_prime(n):
                    print_result("Результат:", value="простое")
                else:
                    print_result("Результат:", value="составное")
            elif op == '2':
                n = safe_int_input("Введите число: ")
                if n <= 1:
                    print(Fore.RED + "Число должно быть больше 1." + Style.RESET_ALL)
                else:
                    factors = factorize(n)
                    print_result("Простые множители:", value=factors)
            elif op == '3':
                n = safe_int_input("Введите число: ")
                res = euler_phi(n)
                print_result(f"φ({n}) =", value=res)
            elif op == '4':
                N = safe_int_input("Введите N: ")
                if N < 2:
                    print(Fore.RED + "N должно быть >= 2." + Style.RESET_ALL)
                else:
                    sieve = [True] * (N+1)
                    sieve[0] = sieve[1] = False
                    for i in range(2, int(N**0.5)+1):
                        if sieve[i]:
                            for j in range(i*i, N+1, i):
                                sieve[j] = False
                    primes = [i for i, p in enumerate(sieve) if p]
                    print_result(f"Простые числа до {N}:", value=primes)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        t(1.5)
        again = input("\nВыполнить другую операцию? (y/n): ").strip().lower()
        if again != 'y':
            break

def physics_calculator():
    """Простые физические формулы (исправленная версия)."""
    while True:
        cls(1)
        print_header("         ФИЗИЧЕСКИЙ КАЛЬКУЛЯТОР         ")
        print("Выберите раздел:")
        print("  1. Кинематика")
        print("  2. Динамика")
        print("  3. Электричество")
        print("  0. Назад")
        section = input("Ваш выбор: ").strip()
        if section == '0':
            break

        if section == '1':
            cls(1)
            print_header("         КИНЕМАТИКА         ")
            print("Формулы:")
            print("  v = v0 + a*t")
            print("  s = v0*t + (a*t^2)/2")
            print("  v^2 - v0^2 = 2*a*s")
            print("Выберите неизвестную величину:")
            print("  1. v (конечная скорость)")
            print("  2. v0 (начальная скорость)")
            print("  3. a (ускорение)")
            print("  4. t (время)")
            print("  5. s (путь)")
            print("  0. Назад")
            op = input("Ваш выбор: ").strip()
            if op == '0':
                continue
            try:
                if op == '1':
                    v0 = safe_float_input("v0 = ")
                    a = safe_float_input("a = ")
                    time_var = safe_float_input("t = ")
                    v = v0 + a * time_var
                    print_result("v =", value=v)
                elif op == '2':
                    v = safe_float_input("v = ")
                    a = safe_float_input("a = ")
                    time_var = safe_float_input("t = ")
                    v0 = v - a * time_var
                    print_result("v0 =", value=v0)
                elif op == '3':
                    v = safe_float_input("v = ")
                    v0 = safe_float_input("v0 = ")
                    time_var = safe_float_input("t = ")
                    a = (v - v0) / time_var
                    print_result("a =", value=a)
                elif op == '4':
                    v = safe_float_input("v = ")
                    v0 = safe_float_input("v0 = ")
                    a = safe_float_input("a = ")
                    if a == 0:
                        print(Fore.RED + "Ускорение не должно быть нулевым." + Style.RESET_ALL)
                    else:
                        time_var = (v - v0) / a
                        print_result("t =", value=time_var)
                elif op == '5':
                    v0 = safe_float_input("v0 = ")
                    time_var = safe_float_input("t = ")
                    a = safe_float_input("a = ")
                    s = v0 * time_var + 0.5 * a * time_var * time_var
                    print_result("s =", value=s)
                else:
                    print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            except Exception as e:
                print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
            t(1.5)

        elif section == '2':
            cls(1)
            print_header("         ДИНАМИКА         ")
            print("Формулы:")
            print("  F = m*a (второй закон Ньютона)")
            print("  F = G * m1 * m2 / r^2 (закон тяготения)")
            print("  F = μ * N (сила трения)")
            print("Выберите:")
            print("  1. F = m*a")
            print("  2. Закон тяготения")
            print("  3. Сила трения")
            print("  0. Назад")
            op = input("Ваш выбор: ").strip()
            if op == '0':
                continue
            try:
                if op == '1':
                    print("Выберите неизвестную:")
                    print("  a) F (сила)")
                    print("  b) m (масса)")
                    print("  c) a (ускорение)")
                    sub = input("Ваш выбор (a/b/c): ").strip().lower()
                    if sub == 'a':
                        m = safe_float_input("m = ")
                        a_val = safe_float_input("a = ")
                        F = m * a_val
                        print_result("F =", value=F)
                    elif sub == 'b':
                        F = safe_float_input("F = ")
                        a_val = safe_float_input("a = ")
                        m = F / a_val
                        print_result("m =", value=m)
                    elif sub == 'c':
                        F = safe_float_input("F = ")
                        m = safe_float_input("m = ")
                        a_val = F / m
                        print_result("a =", value=a_val)
                    else:
                        print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
                elif op == '2':
                    G = 6.67430e-11
                    print("G = 6.67430e-11 м³/(кг·с²)")
                    m1 = safe_float_input("m1 (кг) = ")
                    m2 = safe_float_input("m2 (кг) = ")
                    r = safe_float_input("r (м) = ")
                    if r == 0:
                        print(Fore.RED + "r не может быть нулём." + Style.RESET_ALL)
                    else:
                        F = G * m1 * m2 / (r*r)
                        print_result("F =", value=F)
                elif op == '3':
                    mu = safe_float_input("μ = ")
                    N = safe_float_input("N (нормальная сила, Н) = ")
                    F = mu * N
                    print_result("F =", value=F)
                else:
                    print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            except Exception as e:
                print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
            t(1.5)

        elif section == '3':
            cls(1)
            print_header("         ЭЛЕКТРИЧЕСТВО         ")
            print("Закон Ома: U = I*R")
            print("Мощность: P = U*I = I²*R = U²/R")
            print("Выберите:")
            print("  1. Закон Ома")
            print("  2. Расчёт мощности")
            print("  0. Назад")
            op = input("Ваш выбор: ").strip()
            if op == '0':
                continue
            try:
                if op == '1':
                    print("Выберите неизвестную:")
                    print("  a) U (напряжение)")
                    print("  b) I (ток)")
                    print("  c) R (сопротивление)")
                    sub = input("Ваш выбор (a/b/c): ").strip().lower()
                    if sub == 'a':
                        I = safe_float_input("I (А) = ")
                        R = safe_float_input("R (Ом) = ")
                        U = I*R
                        print_result("U =", value=U)
                    elif sub == 'b':
                        U = safe_float_input("U (В) = ")
                        R = safe_float_input("R (Ом) = ")
                        I = U/R
                        print_result("I =", value=I)
                    elif sub == 'c':
                        U = safe_float_input("U (В) = ")
                        I = safe_float_input("I (А) = ")
                        R = U/I
                        print_result("R =", value=R)
                    else:
                        print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
                elif op == '2':
                    print("Выберите формулу:")
                    print("  a) P = U*I")
                    print("  b) P = I²*R")
                    print("  c) P = U²/R")
                    sub = input("Ваш выбор (a/b/c): ").strip().lower()
                    if sub == 'a':
                        U = safe_float_input("U (В) = ")
                        I = safe_float_input("I (А) = ")
                        P = U*I
                        print_result("P =", value=P)
                    elif sub == 'b':
                        I = safe_float_input("I (А) = ")
                        R = safe_float_input("R (Ом) = ")
                        P = I*I*R
                        print_result("P =", value=P)
                    elif sub == 'c':
                        U = safe_float_input("U (В) = ")
                        R = safe_float_input("R (Ом) = ")
                        P = U*U/R
                        print_result("P =", value=P)
                    else:
                        print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
                else:
                    print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            except Exception as e:
                print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
            t(1.5)
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)

def health_calculator():
    """Калькуляторы здоровья: BMI, BMR, идеальный вес."""
    while True:
        cls(1)
        print_header("         КАЛЬКУЛЯТОР ЗДОРОВЬЯ         ")
        print("Выберите:")
        print("  1. Индекс массы тела (BMI)")
        print("  2. Основной обмен (BMR) по формуле Миффлина-Сан Жеора")
        print("  3. Идеальный вес по формуле Девина")
        print("  0. Назад")
        op = input("Ваш выбор: ").strip()
        if op == '0':
            break

        try:
            if op == '1':
                weight = safe_float_input("Вес (кг): ")
                height = safe_float_input("Рост (см): ")
                if height <= 0:
                    print(Fore.RED + "Рост должен быть положительным." + Style.RESET_ALL)
                else:
                    bmi = weight / ((height/100)**2)
                    print_result("BMI =", value=bmi)
                    if bmi < 18.5:
                        cat = "Недостаточный вес"
                    elif bmi < 25:
                        cat = "Нормальный вес"
                    elif bmi < 30:
                        cat = "Избыточный вес"
                    else:
                        cat = "Ожирение"
                    print(" " * RESULT_INDENT + f"Категория: {cat}")
            elif op == '2':
                sex = input("Пол (м/ж): ").strip().lower()
                weight = safe_float_input("Вес (кг): ")
                height = safe_float_input("Рост (см): ")
                age = safe_int_input("Возраст (лет): ")
                if sex == 'м':
                    bmr = 10*weight + 6.25*height - 5*age + 5
                elif sex == 'ж':
                    bmr = 10*weight + 6.25*height - 5*age - 161
                else:
                    print(Fore.RED + "Неверный пол." + Style.RESET_ALL)
                    continue
                print_result("BMR (ккал/день) =", value=bmr)
            elif op == '3':
                sex = input("Пол (м/ж): ").strip().lower()
                height = safe_float_input("Рост (см): ")
                if sex == 'м':
                    ideal = 50 + 0.9*(height - 152)
                elif sex == 'ж':
                    ideal = 45.5 + 0.9*(height - 152)
                else:
                    print(Fore.RED + "Неверный пол." + Style.RESET_ALL)
                    continue
                print_result("Идеальный вес (кг) по формуле Девина:", value=ideal)
            else:
                print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
        except Exception as e:
            print(Fore.RED + "Ошибка: " + str(e) + Style.RESET_ALL)
        t(1.5)
        again = input("\nВыполнить другой расчёт? (y/n): ").strip().lower()
        if again != 'y':
            break

# ========== НОВЫЙ РАЗДЕЛ: МИНИ-ИГРЫ ==========

def mini_games():
    """Мини-игры для развлечения."""
    while True:
        cls(1)
        print_header("         МИНИ-ИГРЫ         ")
        print("Выберите игру:")
        print("  1. Угадай число")
        print("  2. Камень-ножницы-бумага")
        print("  3. Виселица (угадай слово)")
        print("  4. Крестики-нолики (против компьютера)")
        print("  0. Назад")
        choice = input("Ваш выбор: ").strip()
        if choice == '0':
            break
        elif choice == '1':
            guess_number_game()
        elif choice == '2':
            rock_paper_scissors()
        elif choice == '3':
            hangman_game()
        elif choice == '4':
            tic_tac_toe()
        else:
            print(Fore.RED + "Неверный выбор." + Style.RESET_ALL)
            t(1.5)

def guess_number_game():
    """Игра 'Угадай число'."""
    cls(1)
    print_header("         УГАДАЙ ЧИСЛО         ")
    print("Компьютер загадал число от 1 до 100. Попробуйте угадать!")
    number = random.randint(1, 100)
    attempts = 0
    while True:
        try:
            guess = safe_int_input("Ваш вариант (0 для выхода): ")
            if guess == 0:
                print(Fore.YELLOW + f"Загаданное число было {number}. Жаль, что не угадали!" + Style.RESET_ALL)
                break
            attempts += 1
            if guess < number:
                print(Fore.CYAN + "Больше!" + Style.RESET_ALL)
            elif guess > number:
                print(Fore.CYAN + "Меньше!" + Style.RESET_ALL)
            else:
                print(Fore.GREEN + f"Поздравляю! Вы угадали число {number} за {attempts} попыток." + Style.RESET_ALL)
                break
        except KeyboardInterrupt:
            print(Fore.YELLOW + f"\nИгра прервана. Загадано было {number}." + Style.RESET_ALL)
            break
    t(2)
    input("\nНажмите Enter, чтобы вернуться в меню игр...")

def rock_paper_scissors():
    """Игра 'Камень-ножницы-бумага'."""
    choices = ['камень', 'ножницы', 'бумага']
    while True:
        cls(1)
        print_header("         КАМЕНЬ-НОЖНИЦЫ-БУМАГА         ")
        user = input("Ваш выбор (камень/ножницы/бумага) или 0 для выхода: ").strip().lower()
        if user == '0':
            break
        if user not in choices:
            print(Fore.RED + "Неверный выбор. Попробуйте снова." + Style.RESET_ALL)
            t(1.5)
            continue
        comp = random.choice(choices)
        print(f"Компьютер выбрал: {comp}")
        if user == comp:
            print(Fore.YELLOW + "Ничья!" + Style.RESET_ALL)
        elif (user == 'камень' and comp == 'ножницы') or \
             (user == 'ножницы' and comp == 'бумага') or \
             (user == 'бумага' and comp == 'камень'):
            print(Fore.GREEN + "Вы выиграли!" + Style.RESET_ALL)
        else:
            print(Fore.RED + "Компьютер выиграл!" + Style.RESET_ALL)
        again = input("Ещё раз? (y/n): ").strip().lower()
        if again != 'y':
            break

def hangman_game():
    """Игра 'Виселица' (угадай слово)."""
    words = ['питон', 'программа', 'калькулятор', 'компьютер', 'игра', 'разработка']
    word = random.choice(words)
    guessed = set()
    attempts = 6
    display = ['_' for _ in word]
    while attempts > 0:
        cls(1)
        print_header("         ВИСЕЛИЦА         ")
        print("Слово: " + ' '.join(display))
        print(f"Осталось попыток: {attempts}")
        print("Использованные буквы: " + ', '.join(sorted(guessed)) if guessed else "Пока нет.")
        guess = input("Введите букву или слово целиком: ").strip().lower()
        if not guess:
            continue
        if len(guess) == 1:
            if guess in guessed:
                print(Fore.YELLOW + "Вы уже вводили эту букву." + Style.RESET_ALL)
                t(1)
                continue
            guessed.add(guess)
            if guess in word:
                print(Fore.GREEN + "Есть такая буква!" + Style.RESET_ALL)
                for i, ch in enumerate(word):
                    if ch == guess:
                        display[i] = ch
                if '_' not in display:
                    print(Fore.GREEN + "Поздравляю! Вы угадали слово: " + word + Style.RESET_ALL)
                    break
            else:
                print(Fore.RED + "Нет такой буквы." + Style.RESET_ALL)
                attempts -= 1
        else:
            if guess == word:
                print(Fore.GREEN + "Поздравляю! Вы угадали слово: " + word + Style.RESET_ALL)
                break
            else:
                print(Fore.RED + "Неверно!" + Style.RESET_ALL)
                attempts -= 1
        t(1.5)
    else:
        print(Fore.RED + "Вы проиграли. Загаданное слово: " + word + Style.RESET_ALL)
    t(2)
    input("\nНажмите Enter, чтобы продолжить...")

def tic_tac_toe():
    """Игра 'Крестики-нолики' против компьютера (упрощённая)."""
    board = [' ']*9
    player = 'X'
    computer = 'O'

    def print_board():
        cls(1)
        print("Доска:")
        for i in range(0,9,3):
            print(f" {board[i]} | {board[i+1]} | {board[i+2]} ")
            if i < 6:
                print("---+---+---")
        print()

    def check_win(ch):
        win_comb = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
        return any(board[a]==board[b]==board[c]==ch for a,b,c in win_comb)

    def is_full():
        return ' ' not in board

    def computer_move():
        # Простой алгоритм: сначала попытаться выиграть, затем блокировать игрока, иначе случайно.
        for ch in [computer, player]:
            for i in range(9):
                if board[i] == ' ':
                    board[i] = ch
                    if check_win(ch):
                        if ch == computer:
                            board[i] = computer
                            return i
                        else:
                            board[i] = ' '
                            return i
                    board[i] = ' '
        # Случайный ход
        empty = [i for i in range(9) if board[i] == ' ']
        if empty:
            move = random.choice(empty)
            board[move] = computer
            return move
        return -1

    print_header("         КРЕСТИКИ-НОЛИКИ         ")
    print("Вы играете за X. Компьютер за O.")
    t(2)

    while True:
        print_board()
        # Ход игрока
        move = safe_int_input("Ваш ход (1-9, где 1 левый верхний, 9 правый нижний, 0 для выхода): ")
        if move == 0:
            print(Fore.YELLOW + "Игра прервана." + Style.RESET_ALL)
            break
        if move < 1 or move > 9 or board[move-1] != ' ':
            print(Fore.RED + "Неверный ход. Попробуйте снова." + Style.RESET_ALL)
            t(1.5)
            continue
        board[move-1] = player
        if check_win(player):
            print_board()
            print(Fore.GREEN + "Вы выиграли!" + Style.RESET_ALL)
            break
        if is_full():
            print_board()
            print(Fore.YELLOW + "Ничья!" + Style.RESET_ALL)
            break

        # Ход компьютера
        print("Ход компьютера...")
        t(1)
        computer_move()
        if check_win(computer):
            print_board()
            print(Fore.RED + "Компьютер выиграл!" + Style.RESET_ALL)
            break
        if is_full():
            print_board()
            print(Fore.YELLOW + "Ничья!" + Style.RESET_ALL)
            break
    t(2)
    input("\nНажмите Enter, чтобы вернуться в меню игр...")

# ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ВВОДА ==========

def input_fraction(prompt):
    """Запрашивает у пользователя числитель и знаменатель, возвращает (x, y)."""
    cls(1)
    print(Fore.MAGENTA + prompt + Style.RESET_ALL)
    show_fraction()
    x = safe_int_input("x = ")
    cls(1)
    print(Fore.MAGENTA + "Введите знаменатель:" + Style.RESET_ALL)
    show_fraction(x_val=x)
    y = safe_int_input("y = ")
    return x, y

def input_two_numbers(prompt1, prompt2):
    """Запрашивает два целых числа, возвращает (a, b)."""
    cls(1)
    print(Fore.MAGENTA + prompt1 + Style.RESET_ALL)
    a = safe_int_input("a = ")
    cls(1)
    print(Fore.MAGENTA + prompt2 + Style.RESET_ALL)
    b = safe_int_input("b = ")
    return a, b

# ========== ГЛАВНАЯ ФУНКЦИЯ ==========

def main():
    while True:
        try:
            cls(3)
            print_header("         КАЛЬКУЛЯТОР ДРОБЕЙ И ЧИСЕЛ         ")
            menu_items = {
                '1': 'Сократить дробь',
                '2': 'Сложить две дроби',
                '3': 'Вычесть две дроби',
                '4': 'Умножить две дроби',
                '5': 'Разделить две дроби',
                '6': 'Преобразовать в смешанную',
                '7': 'НОД двух чисел',
                '8': 'НОК двух чисел',
                '9': 'Обычный калькулятор (+, -, *, /)',
                '10': 'Инженерный калькулятор',
                '11': 'Решение уравнений',
                '12': 'Системы линейных уравнений (2x2)',
                '13': 'Статистика',
                '14': 'Проценты',
                '15': 'Конвертер единиц',
                '16': 'Конвертер систем счисления',
                '17': 'Комплексные числа',
                '18': 'Матричный калькулятор (2x2, 3x3)',
                '19': 'Финансовый калькулятор',
                '20': 'Численное интегрирование',
                '21': 'Решение нелинейных уравнений',
                '22': 'Генератор случайных чисел',
                '23': 'Калькулятор дат и времени',
                '24': 'Кубическое уравнение',
                '25': 'Векторный калькулятор',
                '26': 'Решение СЛАУ методом Гаусса',
                '27': 'Комбинаторика',
                '28': 'Битовые операции',
                '29': 'Теория чисел (простые числа)',
                '30': 'Физический калькулятор',
                '31': 'Калькулятор здоровья',
                '32': 'Мини-игры',
                '0': 'Выход'
            }
            print_menu(menu_items)
            choice = input("Выберите действие: ").strip()

            if choice == '0':
                print_header("         ДО СВИДАНИЯ!         ")
                break

            elif choice == '1':
                x, y = input_fraction("Введите дробь для сокращения:")
                nx, ny = reduce_fraction(x, y)
                print_result("Сокращённая дробь:", fraction=(nx, ny))

            elif choice == '2':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = add_fractions(x1, y1, x2, y2)
                print_result("Сумма дробей:", fraction=(nx, ny))

            elif choice == '3':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = sub_fractions(x1, y1, x2, y2)
                print_result("Разность дробей:", fraction=(nx, ny))

            elif choice == '4':
                print("Первая дробь:")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь:")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = mul_fractions(x1, y1, x2, y2)
                print_result("Произведение дробей:", fraction=(nx, ny))

            elif choice == '5':
                print("Первая дробь (делимое):")
                x1, y1 = input_fraction("Введите первую дробь:")
                print("Вторая дробь (делитель):")
                x2, y2 = input_fraction("Введите вторую дробь:")
                nx, ny = div_fractions(x1, y1, x2, y2)
                print_result("Частное дробей:", fraction=(nx, ny))

            elif choice == '6':
                x, y = input_fraction("Введите дробь для преобразования:")
                print("Смешанная дробь:")
                print_result_mixed(x, y)

            elif choice == '7':
                a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
                res = gcd_numbers(a, b)
                print_result(f"НОД({a}, {b}) =", value=res)

            elif choice == '8':
                a, b = input_two_numbers("Введите первое число (a):", "Введите второе число (b):")
                res = lcm_numbers(a, b)
                print_result(f"НОК({a}, {b}) =", value=res)

            elif choice == '9':
                simple_calculator()

            elif choice == '10':
                engineering_calculator()

            elif choice == '11':
                solve_equations()

            elif choice == '12':
                systems_of_equations()

            elif choice == '13':
                statistics_calculator()

            elif choice == '14':
                percentage_calculator()

            elif choice == '15':
                unit_converter()

            elif choice == '16':
                base_converter()

            elif choice == '17':
                complex_calculator()

            elif choice == '18':
                matrix_calculator()

            elif choice == '19':
                financial_calculator()

            elif choice == '20':
                numeric_integration()

            elif choice == '21':
                nonlinear_solver()

            elif choice == '22':
                random_generator()

            elif choice == '23':
                date_time_calculator()

            elif choice == '24':
                cubic_equation_solver()

            elif choice == '25':
                vector_calculator()

            elif choice == '26':
                gauss_elimination()

            elif choice == '27':
                combinatorics()

            elif choice == '28':
                bitwise_operations()

            elif choice == '29':
                prime_numbers()

            elif choice == '30':
                physics_calculator()

            elif choice == '31':
                health_calculator()

            elif choice == '32':
                mini_games()

            else:
                print(Fore.RED + "Неверный выбор. Попробуйте снова." + Style.RESET_ALL)

        except KeyboardInterrupt:
            print(Fore.YELLOW + "\nВыход по запросу пользователя." + Style.RESET_ALL)
            break
        except Exception as e:
            print(Fore.RED + "Произошла непредвиденная ошибка: " + str(e) + Style.RESET_ALL)
            t(1.5)

        t(1.5)
        input("\nНажмите Enter, чтобы продолжить...")

if __name__ == "__main__":
    main()