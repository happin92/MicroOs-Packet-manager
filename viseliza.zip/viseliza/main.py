import random
import os

# ASCII-изображения виселицы для каждого количества ошибок (0-6)
HANGMAN_PICS = [
    """
     ------
     |    |
     |
     |
     |
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |
     |
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |    |
     |
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |   /|
     |
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |   /|\\
     |
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |   /|\\
     |   /
     |
    ---
    """,
    """
     ------
     |    |
     |    O
     |   /|\\
     |   / \\
     |
    ---
    """
]

def clear_screen():
    """Очищает экран (для удобства игры)."""
    os.system('cls' if os.name == 'nt' else 'clear')

def choose_difficulty():
    """Выбор уровня сложности (количество попыток)."""
    print("Выберите уровень сложности:")
    print("1 - Легкий (8 попыток)")
    print("2 - Средний (6 попыток)")
    print("3 - Сложный (4 попытки)")
    while True:
        choice = input("Ваш выбор (1/2/3): ").strip()
        if choice == "1":
            return 8
        elif choice == "2":
            return 6
        elif choice == "3":
            return 4
        else:
            print("Некорректный ввод. Попробуйте снова.")

def get_word_list():
    """Возвращает список слов на русском и английском."""
    # Можно расширить или загружать из файла, но здесь статичный набор
    return {
        'ru': ["питон", "программа", "игра", "компьютер", "разработка", "алгоритм", "код", "виселица", "яблоко", "автомобиль"],
        'en': ["python", "program", "game", "computer", "developer", "algorithm", "code", "hangman", "apple", "car"]
    }

def choose_language():
    """Выбор языка слов."""
    print("Выберите язык слов:")
    print("1 - Русский")
    print("2 - Английский")
    while True:
        choice = input("Ваш выбор (1/2): ").strip()
        if choice == "1":
            return 'ru'
        elif choice == "2":
            return 'en'
        else:
            print("Некорректный ввод. Попробуйте снова.")

def display_board(masked_word, wrong_letters, attempts_left, max_attempts):
    """Отображает текущее состояние игры с ASCII-виселицей."""
    clear_screen()
    # Индекс для картинки: количество совершённых ошибок = max_attempts - attempts_left
    errors = max_attempts - attempts_left
    print(HANGMAN_PICS[errors])
    print("\nСлово: " + " ".join(masked_word))
    if wrong_letters:
        print("Ошибочные буквы: " + ", ".join(sorted(wrong_letters)))
    print("Осталось попыток: " + str(attempts_left))

def get_guess(guessed_letters, language):
    """Запрашивает букву с учётом языка (для проверки алфавита)."""
    while True:
        guess = input("Введите букву: ").strip().lower()
        if len(guess) != 1:
            print("Ошибка: введите ровно одну букву.")
            continue
        if language == 'ru' and guess.isalpha() and ('а' <= guess <= 'я' or guess == 'ё'):
            pass  # допустимая русская буква
        elif language == 'en' and guess.isalpha() and 'a' <= guess <= 'z':
            pass  # допустимая английская буква
        else:
            print("Ошибка: введите букву выбранного языка.")
            continue
        if guess in guessed_letters:
            print("Ошибка: вы уже вводили эту букву.")
            continue
        return guess

def play():
    """Основной игровой цикл."""
    clear_screen()
    print("Добро пожаловать в игру «Виселица»!\n")

    # Настройки игры
    language = choose_language()
    max_attempts = choose_difficulty()
    words = get_word_list()[language]
    word = random.choice(words)
    masked = ["_"] * len(word)
    wrong_letters = []
    guessed_letters = set()
    attempts_left = max_attempts

    while attempts_left > 0 and "_" in masked:
        display_board(masked, wrong_letters, attempts_left, max_attempts)
        guess = get_guess(guessed_letters, language)
        guessed_letters.add(guess)

        if guess in word:
            # Открываем все вхождения буквы
            for i, letter in enumerate(word):
                if letter == guess:
                    masked[i] = guess
            print("✓ Буква есть в слове!")
            input("Нажмите Enter, чтобы продолжить...")
        else:
            wrong_letters.append(guess)
            attempts_left -= 1
            print("✗ Такой буквы нет.")
            input("Нажмите Enter, чтобы продолжить...")

    # Финальный экран
    clear_screen()
    if "_" not in masked:
        print(HANGMAN_PICS[0])  # радостная виселица без ошибок
        print(f"Поздравляем! Вы угадали слово: {word.upper()}")
    else:
        print(HANGMAN_PICS[max_attempts - attempts_left])  # финальная картинка
        print(f"Вы проиграли. Загаданное слово было: {word.upper()}")

def main():
    """Запускает игру с подсчётом статистики."""
    wins = 0
    losses = 0
    while True:
        play()
        # Спрашиваем, угадано ли слово (простой способ узнать результат последней игры)
        # В текущей реализации мы не передаём результат наружу, поэтому предложим пользователю самому указать.
        # Более правильно было бы возвращать результат из play(), но для простоты спросим.
        result = input("Вы выиграли? (да/нет): ").strip().lower()
        if result in ("да", "yes", "y", "д"):
            wins += 1
        else:
            losses += 1
        print(f"\n--- Статистика ---\nПобед: {wins}  Поражений: {losses}\n")
        again = input("Хотите сыграть ещё? (да/нет): ").strip().lower()
        if again not in ("да", "yes", "y", "д"):
            print("Спасибо за игру! До свидания.")
            break

if __name__ == "__main__":
    main()