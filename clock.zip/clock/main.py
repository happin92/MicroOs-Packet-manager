import sys
import time
import datetime
import os
import select
import tty
import termios

# ANSI-последовательности
CURSOR_HOME = "\033[H"
ERASE_SCREEN = "\033[2J"
COLOR_RESET = "\033[0m"
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_CYAN = "\033[96m"
COLOR_WHITE = "\033[97m"

# Русские названия (краткие)
WEEKDAYS_RU_SHORT = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
MONTHS_RU_SHORT = ["янв", "фев", "мар", "апр", "мая", "июн",
                   "июл", "авг", "сен", "окт", "ноя", "дек"]

def get_terminal_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 40

def supports_utf8():
    encoding = sys.stdout.encoding
    return encoding and 'UTF-8' in encoding.upper()

if supports_utf8():
    BOX = {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘",
           "h": "─", "v": "│", "lh": "├", "rh": "┤"}
else:
    BOX = {"tl": "+", "tr": "+", "bl": "+", "br": "+",
           "h": "-", "v": "|", "lh": "+", "rh": "+"}

def set_color(color):
    sys.stdout.write(color)

def reset_color():
    sys.stdout.write(COLOR_RESET)

def format_time(dt, use_12h=False):
    if use_12h:
        hour = dt.hour % 12
        if hour == 0:
            hour = 12
        ampm = "AM" if dt.hour < 12 else "PM"
        return f"{hour:02d}:{dt.minute:02d}:{dt.second:02d} {ampm}"
    else:
        return dt.strftime("%H:%M:%S")

def format_date_short(dt):
    return f"{dt.day} {MONTHS_RU_SHORT[dt.month-1]} {dt.year}"

def format_weekday_short(dt):
    return WEEKDAYS_RU_SHORT[dt.weekday()]

def draw_clock(use_12h=False):
    old_settings = termios.tcgetattr(sys.stdin)
    try:
        tty.setcbreak(sys.stdin.fileno())
        width = min(get_terminal_width(), 40)
        inner_width = width - 2

        def print_line(content="", color=None):
            if color:
                set_color(color)
            if len(content) > inner_width:
                content = content[:inner_width]
            else:
                content = content.ljust(inner_width)
            sys.stdout.write(f"{BOX['v']}{content}{BOX['v']}\n")
            if color:
                reset_color()

        while True:
            # Проверка нажатия 'q'
            if select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], []):
                if sys.stdin.read(1) == 'q':
                    break

            now = datetime.datetime.now()
            date_str = format_date_short(now)
            weekday_str = format_weekday_short(now)
            time_str = format_time(now, use_12h)

            # Полная перерисовка экрана
            sys.stdout.write(ERASE_SCREEN + CURSOR_HOME)
            # Верхняя граница
            sys.stdout.write(BOX['tl'] + BOX['h'] * inner_width + BOX['tr'] + "\n")
            # Заголовок
            print_line(" ЧАСЫ ", COLOR_YELLOW)
            # Разделитель
            sys.stdout.write(BOX['lh'] + BOX['h'] * inner_width + BOX['rh'] + "\n")
            # Дата
            print_line(f" {date_str}  {weekday_str}", COLOR_CYAN)
            # Время
            print_line(f" {time_str}", COLOR_GREEN)
            # Подсказка (одна строка)
            print_line(" Нажми 'q' для выхода", COLOR_WHITE)
            # Нижняя граница
            sys.stdout.write(BOX['bl'] + BOX['h'] * inner_width + BOX['br'] + "\n")
            sys.stdout.flush()

            time.sleep(0.5)  # полсекунды для экономии заряда, можно поставить 1

    except KeyboardInterrupt:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        reset_color()
        print("\n🕒 Часы остановлены. До свидания!")

if __name__ == "__main__":
    use_12h = "12" in sys.argv[1:]
    draw_clock(use_12h)